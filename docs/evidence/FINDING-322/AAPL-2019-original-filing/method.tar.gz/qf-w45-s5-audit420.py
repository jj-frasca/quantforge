"""One fixed original-filing witness audit; no acquisition or production parser."""
import calendar
import hashlib
import io
import re
from decimal import Decimal, InvalidOperation
from xml.etree import ElementTree as ET

X = 'http://www.xbrl.org/2003/instance'
IX = {'http://www.xbrl.org/2013/inlineXBRL', 'http://www.xbrl.org/2008/inlineXBRL'}
TRANSFORMS = {'http://www.xbrl.org/inlineXBRL/transformation/' + date for date in ['2011-07-31','2015-02-26','2020-02-12','2022-02-16']}
REVENUE = 'RevenueFromContractWithCustomerExcludingAssessedTax'
DEI = {'DocumentType':'10-K','DocumentPeriodEndDate':'2019-09-28','DocumentFiscalYearFocus':'2019','DocumentFiscalPeriodFocus':'FY'}
ANNUAL = ('2018-09-30','2019-09-28')
QUARTER = ('2019-06-30','2019-09-28')


def split_name(name):
    if name.startswith('{'):
        return tuple(name[1:].split('}',1))
    return ('',name)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def audit(raw):
    result={'linkage':'UNSUPPORTED','source_sha256':sha(raw),'source_bytes':len(raw),'header':{},'inventory':[], 'documents':[], 'counts':{'documents':0,'revenue_candidates':0,'dei_candidates':0},'reasons':[]}
    contradictory=[]
    unsupported=[]
    text=raw.decode('utf-8',errors='replace')
    if '\ufffd' in text:
        unsupported.append('source is not supported UTF-8 text')
    header_match=re.search(r'<SEC-HEADER>(.*?)</SEC-HEADER>',text,re.S|re.I)
    header=header_match.group(1) if header_match else ''
    result['header']['raw']=header
    for key,label in [('accession','ACCESSION NUMBER'),('form','CONFORMED SUBMISSION TYPE'),('cik','CENTRAL INDEX KEY'),('report_end','CONFORMED PERIOD OF REPORT'),('filed','FILED AS OF DATE'),('changed','DATE AS OF CHANGE')]:
        vals=re.findall(r'^\s*'+re.escape(label)+r':\s*([^\r\n]+)',header,re.M)
        result['header'][key]=vals
    acceptance=re.findall(r'<ACCEPTANCE-DATETIME>\s*([^\r\n<]+)',text,re.I)
    result['header']['acceptance_raw']=acceptance[0].strip() if len(acceptance)==1 else None
    expected={'accession':'0000320193-19-000119','form':'10-K','cik':'0000320193','report_end':'20190928'}
    for key,want in expected.items():
        values=result['header'][key]
        normalized=[str(int(v)) if key=='cik' and v.isdigit() else v for v in values]
        target=str(int(want)) if key=='cik' else want
        if not values:
            unsupported.append('missing header '+key)
        elif set(normalized)!={target}:
            contradictory.append('header mismatch '+key)
    for key in ('filed','changed'):
        if len(result['header'][key])!=1:
            unsupported.append('missing or ambiguous header '+key)
    if len(acceptance)!=1:
        unsupported.append('missing or ambiguous header acceptance')
    documents=[]
    blocks=list(re.finditer(br'<DOCUMENT>(.*?)</DOCUMENT>',raw,re.S|re.I))
    if len(re.findall(br'<DOCUMENT>',raw,re.I))!=len(blocks):
        unsupported.append('unbalanced DOCUMENT blocks')
    for index,match in enumerate(blocks):
        block=match.group(1)
        metadata={}
        for key,tag in [('type','TYPE'),('filename','FILENAME'),('sequence','SEQUENCE')]:
            values=re.findall(br'<'+tag.encode()+br'>\s*([^\r\n<]+)',block,re.I)
            metadata[key]=[v.decode('utf-8',errors='replace').strip() for v in values]
        bodies=re.findall(br'<TEXT>\s*(.*?)\s*</TEXT>',block,re.S|re.I)
        info={'index':index,'type':metadata['type'][0] if len(metadata['type'])==1 else None,'filename':metadata['filename'][0] if len(metadata['filename'])==1 else None,'sequence':metadata['sequence'],'block_sha256':sha(match.group(0)),'block_bytes':len(match.group(0)), 'body_sha256':sha(bodies[0]) if len(bodies)==1 else None,'body_bytes':len(bodies[0]) if len(bodies)==1 else None}
        result['inventory'].append(info)
        if len(bodies)==1 and info['type'] in {'10-K','EX-101.INS'}:
            documents.append((info,bodies[0]))
    result['counts']['documents']=len(blocks)
    standalone=[doc for doc in documents if doc[0]['type']=='EX-101.INS']
    selected=standalone if standalone else [doc for doc in documents if doc[0]['type']=='10-K']
    result['representation']='standalone' if standalone else 'inline'
    if not selected:
        unsupported.append('no supported included financial representation')
    passed_documents=[]
    for info,body in selected:
        doc={'inventory_index':info['index'],'contexts':{},'units':{},'facts':[],'dei':[],'reasons':[]}
        result['documents'].append(doc)
        local_unsupported=[]
        local_contradicted=[]
        if re.search(br'<!DOCTYPE|<!ENTITY',body,re.I):
            unsupported.append('DOCTYPE/entity declaration not supported')
            continue
        wrapper=re.fullmatch(br'<XBRL>\s*(.*?)\s*</XBRL>',body.strip(),re.S)
        parse_body=wrapper.group(1) if wrapper else body
        doc['sgml_xbrl_wrapper']=bool(wrapper)
        doc['parse_body_sha256']=sha(parse_body)
        namespaces={}
        try:
            for event,item in ET.iterparse(io.BytesIO(parse_body),events=('start-ns',)):
                prefix,uri=item
                if prefix in namespaces and namespaces[prefix]!=uri:
                    local_unsupported.append('ambiguous namespace prefix '+prefix)
                namespaces[prefix]=uri
            tree=ET.fromstring(parse_body)
        except ET.ParseError as exc:
            unsupported.append('malformed local XML: '+str(exc))
            continue
        if standalone and split_name(tree.tag)!=(X,'xbrl'):
            unsupported.append('standalone representation lacks XBRL instance root')
            continue
        doc['namespaces']=namespaces
        def qname(value):
            if ':' not in value:
                uri=namespaces.get('','')
                return uri,value
            prefix,local=value.split(':',1)
            if prefix not in namespaces:
                raise ValueError('unresolved QName '+value)
            return namespaces[prefix],local
        for node in tree.iter():
            uri,local=split_name(node.tag)
            if uri!=X or local not in {'context','unit'}:
                continue
            identity=node.get('id')
            if not identity:
                local_unsupported.append('context/unit lacks ID')
                continue
            store=doc['contexts'] if local=='context' else doc['units']
            original=ET.tostring(node,encoding='unicode')
            if identity in store:
                local_contradicted.append('duplicate '+local+' ID '+identity)
                continue
            if local=='context':
                identifiers=node.findall('.//{'+X+'}identifier')
                starts=node.findall('.//{'+X+'}startDate'); ends=node.findall('.//{'+X+'}endDate'); instants=node.findall('.//{'+X+'}instant')
                dims=any(split_name(n.tag)[1] in {'segment','scenario','explicitMember','typedMember'} for n in node.iter())
                store[identity]={'xml':original,'identifier':identifiers[0].text if len(identifiers)==1 else None,'scheme':identifiers[0].get('scheme') if len(identifiers)==1 else None,'starts':[n.text for n in starts],'ends':[n.text for n in ends],'instants':[n.text for n in instants],'has_dimensions_or_scenario':dims}
            else:
                measures=node.findall('.//{'+X+'}measure')
                try:
                    values=[qname((n.text or '').strip()) for n in measures]
                except ValueError as exc:
                    local_unsupported.append(str(exc)); values=[]
                store[identity]={'xml':original,'measures':values,'simple':len(list(node))==1 and len(measures)==1 and split_name(list(node)[0].tag)==(X,'measure')}
        def context_ok(context):
            if context is None:
                return False
            identifier=context['identifier'] or ''
            return identifier.isdigit() and int(identifier)==320193 and context['scheme']=='http://www.sec.gov/CIK' and not context['has_dimensions_or_scenario'] and not context['instants'] and len(context['starts'])==len(context['ends'])==1
        def transform(node,allowed):
            fmt=node.get('format')
            if fmt is None:
                return
            trans_uri,trans_local=qname(fmt)
            if trans_uri not in TRANSFORMS or trans_local not in allowed:
                raise ValueError('unsupported transform '+fmt)
        def numeric(node,inline):
            if any(split_name(n.tag)[0] in IX and split_name(n.tag)[1]=='exclude' for n in node.iter()):
                raise ValueError('unsupported inline exclude')
            if any(split_name(k)[1]=='nil' for k in node.attrib) or node.get('continuedAt') is not None or split_name(node.tag)[1]=='fraction':
                raise ValueError('unsupported nil/fraction/continuation')
            if inline:
                transform(node,{'numdotdecimal','num-dot-decimal'})
            value=''.join(node.itertext()).strip()
            if not re.fullmatch(r'[+-]?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?',value):
                raise ValueError('unsupported numeric lexical value')
            if ',' in value and (not inline or node.get('format') is None):
                raise ValueError('grouped number requires declared inline transform')
            exponent=node.get('scale','0')
            if not re.fullmatch(r'[+-]?\d+',exponent) or not -18<=int(exponent)<=18:
                raise ValueError('unsupported scale')
            sign=node.get('sign')
            if sign not in {None,'-'}:
                raise ValueError('unsupported sign')
            parsed=Decimal(value.replace(',',''))
            if sign=='-':
                parsed=parsed.copy_negate()
            parts=parsed.as_tuple()
            return str(Decimal((parts.sign,parts.digits,parts.exponent+int(exponent))))
        for node in tree.iter():
            uri,local=split_name(node.tag)
            inline=uri in IX and local in {'nonNumeric','nonFraction','fraction'}
            try:
                concept_uri,concept=qname(node.get('name','')) if inline else (uri,local)
            except ValueError as exc:
                local_unsupported.append(str(exc)); continue
            is_revenue=concept==REVENUE
            is_dei=concept in DEI
            if not is_revenue and not is_dei:
                continue
            expected_prefix='http://fasb.org/us-gaap/' if is_revenue else 'http://xbrl.sec.gov/dei/'
            if not concept_uri.startswith(expected_prefix):
                local_unsupported.append('unsupported concept namespace '+concept_uri)
                continue
            context_id=node.get('contextRef')
            context=doc['contexts'].get(context_id)
            fact={'id':node.get('id'),'concept':concept,'namespace':concept_uri,'contextRef':context_id,'unitRef':node.get('unitRef'),'attributes':dict(node.attrib),'text':''.join(node.itertext()),'xml':ET.tostring(node,encoding='unicode'),'context_valid':context_ok(context),'error':None}
            if is_revenue:
                doc['facts'].append(fact); result['counts']['revenue_candidates']+=1
                try:
                    fact['value']=numeric(node,inline)
                except (ValueError,InvalidOperation) as exc:
                    fact['error']=str(exc); local_unsupported.append(str(exc))
                unit=doc['units'].get(node.get('unitRef'))
                fact['unit_valid']=bool(unit and unit['simple'] and unit['measures']==[('http://www.xbrl.org/2003/iso4217','USD')])
                fact['admitted']=bool(fact['context_valid'] and fact['unit_valid'] and not fact['error'])
            else:
                doc['dei'].append(fact); result['counts']['dei_candidates']+=1
                value=fact['text'].strip()
                try:
                    if any(split_name(n.tag)[0] in IX and split_name(n.tag)[1]=='exclude' for n in node.iter()):
                        raise ValueError('unsupported DEI inline exclude')
                    if node.get('continuedAt') is not None or any(split_name(k)[1]=='nil' for k in node.attrib):
                        raise ValueError('unsupported DEI nil/continuation')
                    if concept=='DocumentPeriodEndDate':
                        transform(node,{'datemonthdayyearen','date-monthname-day-year-en'})
                        if not re.fullmatch(r'\d{4}-\d{2}-\d{2}',value):
                            match=re.fullmatch(r'([A-Za-z]+)\s+(\d{1,2}),?\s+(\d{4})',value)
                            if not match or match[1] not in list(calendar.month_name):
                                raise ValueError('unsupported DEI date')
                            value=f'{int(match[3]):04}-{list(calendar.month_name).index(match[1]):02}-{int(match[2]):02}'
                    elif node.get('format') is not None:
                        raise ValueError('unsupported DEI transform')
                    fact['value']=value
                except ValueError as exc:
                    fact['error']=str(exc); local_unsupported.append(str(exc))
        for concept,want in DEI.items():
            candidates=[f for f in doc['dei'] if f['concept']==concept]
            if not candidates:
                local_unsupported.append('missing DEI '+concept); continue
            values={f.get('value') for f in candidates if not f['error']}
            if len(values)>1 or (values and values!={want}):
                local_contradicted.append('contradictory DEI '+concept)
            if values!={want} or any(not f['context_valid'] or f['error'] for f in candidates):
                local_unsupported.append('unresolved DEI '+concept)
            if any((doc['contexts'].get(f['contextRef'],{}).get('starts'),doc['contexts'].get(f['contextRef'],{}).get('ends'))!=([ANNUAL[0]],[ANNUAL[1]]) for f in candidates):
                local_unsupported.append('DEI does not bind annual interval '+concept)
        for label,period,want in [('annual',ANNUAL,Decimal('260174000000')),('quarter',QUARTER,Decimal('64040000000'))]:
            candidates=[f for f in doc['facts'] if f['admitted'] and (doc['contexts'].get(f['contextRef'],{}).get('starts'),doc['contexts'].get(f['contextRef'],{}).get('ends'))==([period[0]],[period[1]])]
            if not candidates:
                local_unsupported.append('missing '+label+' witness'); continue
            values={Decimal(f['value']) for f in candidates if not f['error']}
            if len(values)>1 or (values and values!={want}):
                local_contradicted.append('conflicting '+label+' revenue')
            if values!={want} or any(not f['context_valid'] or not f['unit_valid'] or f['error'] for f in candidates):
                local_unsupported.append('unresolved '+label+' witness')
        # A target concept with an unresolved context cannot be silently ignored.
        if any(f['contextRef'] not in doc['contexts'] for f in doc['facts']):
            local_unsupported.append('revenue candidate has unresolved context reference')
        doc['reasons']=local_contradicted+local_unsupported
        contradictory.extend(local_contradicted)
        unsupported.extend(local_unsupported)
        passed_documents.append(not local_contradicted and not local_unsupported)
    result['reasons']=contradictory+unsupported
    result['linkage']='CONTRADICTED' if contradictory else ('PASS' if passed_documents and all(passed_documents) and not unsupported else 'UNSUPPORTED')
    return result
