"""ADR420 acquisition-only one-attempt driver. Importing this file performs no I/O."""
import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

import httpx

URL = 'https://www.sec.gov/Archives/edgar/data/320193/000032019319000119/0000320193-19-000119.txt'
USER_AGENT = 'QuantForge research jjfrasca10@gmail.com'
REGISTERED_ROOT = Path('/tmp/qf-w45-s5-original-aapl2019')
REPO = Path('/Users/joefrasca/claude-work/quantforge-codex')
PROTOCOL = REPO / 'docs/adr/ADR-420-freeze-one-original-filing-context-witness.md'
BODY_LIMIT = 64 * 1024 * 1024
ELAPSED_LIMIT = 60.0
HEADERS = {'User-Agent': USER_AGENT, 'Accept': 'text/plain', 'Accept-Encoding': 'identity'}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def durable(path, data):
    with path.open('xb') as handle:
        handle.write(data)
        handle.flush()
        os.fsync(handle.fileno())


def json_bytes(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()


def capture(root, protocol_path, expected_protocol_sha, *, transport=None, max_body=BODY_LIMIT, clock=time.monotonic):
    """One invocation; transport/limits/clock injection exists only for offline tests."""
    root = Path(root)
    protocol_data = Path(protocol_path).read_bytes()
    if sha(protocol_data) != expected_protocol_sha:
        raise ValueError('protocol bytes do not match frozen protocol SHA256')
    if max_body <= 0 or max_body > BODY_LIMIT:
        raise ValueError('invalid body limit')
    script_data = Path(__file__).read_bytes()
    git_revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
    module_path = Path(httpx.__file__)
    lock_data = (REPO / 'backend/uv.lock').read_bytes()
    root.mkdir(exist_ok=False)
    started = clock()
    start = {
        'schema': 'adr420-one-attempt-v1',
        'request_started_at_utc': utc_now(),
        'protocol_sha256': sha(protocol_data),
        'script_sha256': sha(script_data),
        'git_revision': git_revision,
        'httpx_version': httpx.__version__,
        'httpx_module_path': str(module_path),
        'httpx_module_sha256': sha(module_path.read_bytes()),
        'uv_lock_sha256': sha(lock_data),
        'source': {'cik': 320193, 'accession': '0000320193-19-000119', 'url': URL, 'headers': HEADERS},
        'policy': {'body_limit_decoded_bytes': max_body, 'elapsed_limit_seconds': ELAPSED_LIMIT,
                   'timeouts': {'connect': 10, 'read': 15, 'write': 15, 'pool': 10},
                   'retries': 0, 'follow_redirects': False, 'trust_env': False},
    }
    durable(root / 'START.json', json_bytes(start))
    durable(root / 'protocol.md', protocol_data)
    durable(root / 'capture-script.py', script_data)
    receipt = dict(start)
    receipt.update({'http_status': None, 'final_url': None, 'response_headers': {},
                    'exception_type': None, 'exception_message': None,
                    'observed_decoded_bytes': 0, 'acquisition_status': 'UNEVALUABLE',
                    'scientific_status': 'NOT_AUDITED', 'reason': None})
    raw_path = root / 'response.raw'
    retained = 0
    timeout = httpx.Timeout(connect=10.0, read=15.0, write=15.0, pool=10.0)
    try:
        with raw_path.open('xb') as body:
            # HTTPTransport retries=0 and trust_env=False exclude implicit network retries/proxies.
            active_transport = transport if transport is not None else httpx.HTTPTransport(retries=0, trust_env=False)
            with httpx.Client(transport=active_transport, timeout=timeout, follow_redirects=False,
                              trust_env=False, headers=HEADERS, auth=None) as client:
                with client.stream('GET', URL) as response:
                    receipt['http_status'] = response.status_code
                    receipt['final_url'] = str(response.url)
                    selected = ('date', 'content-type', 'content-length', 'content-encoding', 'location', 'etag', 'last-modified')
                    receipt['response_headers'] = {key: response.headers[key] for key in selected if key in response.headers}
                    for chunk in response.iter_bytes():
                        receipt['observed_decoded_bytes'] += len(chunk)
                        if clock() - started >= ELAPSED_LIMIT:
                            receipt['reason'] = 'elapsed_limit'
                            break
                        admitted = chunk[:max_body - retained]
                        body.write(admitted)
                        retained += len(admitted)
                        body.flush()
                        os.fsync(body.fileno())
                        if retained >= max_body:
                            receipt['reason'] = 'body_limit'
                            break
            body.flush()
            os.fsync(body.fileno())
    except Exception as exc:
        receipt['reason'] = 'exception'
        receipt['exception_type'] = type(exc).__name__
        receipt['exception_message'] = str(exc)
    # BaseException interruption intentionally leaves only durable START + available partial bytes.
    elapsed = clock() - started
    if receipt['reason'] is None and elapsed >= ELAPSED_LIMIT:
        receipt['reason'] = 'elapsed_limit'
    raw = raw_path.read_bytes() if raw_path.exists() else b''
    if receipt['reason'] is None:
        if receipt['http_status'] != 200:
            receipt['reason'] = 'http_status'
        elif not raw:
            receipt['reason'] = 'empty_body'
        else:
            receipt['acquisition_status'] = 'CAPTURED'
            receipt['reason'] = 'transport_complete'
    compressed = gzip.compress(raw, mtime=0)
    durable(root / 'response.raw.gz', compressed)
    receipt.update({'request_completed_at_utc': utc_now(), 'elapsed_seconds': elapsed,
                    'raw_byte_count': len(raw), 'raw_sha256': sha(raw),
                    'gzip_byte_count': len(compressed), 'gzip_sha256': sha(compressed),
                    'raw_representation': 'HTTPX decoded response bytes; Accept-Encoding identity requested',
                    'partial_body': receipt['reason'] in ('exception', 'body_limit', 'elapsed_limit')})
    durable(root / 'RESULT.json', json_bytes(receipt))
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--protocol-sha', required=True, help='accepted frozen ADR420 raw SHA256; never compute a replacement after START')
    args = parser.parse_args()
    result = capture(REGISTERED_ROOT, PROTOCOL, args.protocol_sha)
    print(json.dumps({'acquisition_status': result['acquisition_status'], 'reason': result['reason'],
                      'raw_byte_count': result['raw_byte_count'], 'raw_sha256': result['raw_sha256']}))


if __name__ == '__main__':
    main()
