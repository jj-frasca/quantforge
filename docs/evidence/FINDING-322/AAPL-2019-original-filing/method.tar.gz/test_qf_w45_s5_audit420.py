import importlib.util
from pathlib import Path

import pytest

spec = importlib.util.spec_from_file_location('audit420', Path(__file__).with_name('qf-w45-s5-audit420.py'))
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)


def fixture(inline=False):
    header = '<SEC-HEADER>\nACCESSION NUMBER: 0000320193-19-000119\nCONFORMED SUBMISSION TYPE: 10-K\nCENTRAL INDEX KEY: 0000320193\nCONFORMED PERIOD OF REPORT: 20190928\nFILED AS OF DATE: 20191031\nDATE AS OF CHANGE: 20191031\n<ACCEPTANCE-DATETIME>20191030181236\n</SEC-HEADER>'
    namespaces = 'xmlns:xbrli="http://www.xbrl.org/2003/instance" xmlns:dei="http://xbrl.sec.gov/dei/2019-01-31" xmlns:us-gaap="http://fasb.org/us-gaap/2019-01-31" xmlns:iso4217="http://www.xbrl.org/2003/iso4217" xmlns:ix="http://www.xbrl.org/2013/inlineXBRL" xmlns:ixt="http://www.xbrl.org/inlineXBRL/transformation/2015-02-26"'
    contexts = ''.join(f'<xbrli:context id="{key}"><xbrli:entity><xbrli:identifier scheme="http://www.sec.gov/CIK">0000320193</xbrli:identifier></xbrli:entity><xbrli:period><xbrli:startDate>{start}</xbrli:startDate><xbrli:endDate>2019-09-28</xbrli:endDate></xbrli:period></xbrli:context>' for key,start in [('annual','2018-09-30'),('quarter','2019-06-30')])
    unit = '<xbrli:unit id="USD"><xbrli:measure>iso4217:USD</xbrli:measure></xbrli:unit>'
    dei = ''.join(f'<dei:{name} contextRef="annual">{value}</dei:{name}>' for name,value in [('DocumentType','10-K'),('DocumentPeriodEndDate','2019-09-28'),('DocumentFiscalYearFocus','2019'),('DocumentFiscalPeriodFocus','FY')])
    def fact(context,value):
        name='RevenueFromContractWithCustomerExcludingAssessedTax'
        if inline:
            return f'<ix:nonFraction name="us-gaap:{name}" contextRef="{context}" unitRef="USD" scale="6" format="ixt:numdotdecimal" decimals="-6">{value}</ix:nonFraction>'
        return f'<us-gaap:{name} contextRef="{context}" unitRef="USD" decimals="-6">{value}</us-gaap:{name}>'
    facts = fact('annual','260,174' if inline else '260174000000')+fact('quarter','64,040' if inline else '64040000000')
    root='html' if inline else 'xbrli:xbrl'
    xml=f'<{root} {namespaces}>{contexts}{unit}{dei}{facts}</{root}>'
    kind='10-K' if inline else 'EX-101.INS'
    return (header+f'<DOCUMENT>\n<TYPE>{kind}\n<SEQUENCE>1\n<FILENAME>witness.xml\n<TEXT>\n{xml}\n</TEXT>\n</DOCUMENT>').encode()


@pytest.mark.parametrize('inline',[False,True])
def test_pass(inline):
    result=mod.audit(fixture(inline))
    assert result['linkage']=='PASS', result
    assert result['header']['acceptance_raw']=='20191030181236'
    assert result['inventory'][0]['filename']=='witness.xml'
    assert result['counts']['revenue_candidates']==2


@pytest.mark.parametrize('before,after',[
    (b'<xbrli:entity>',b'<xbrli:scenario><xbrli:segment/></xbrli:scenario><xbrli:entity>'),
    (b'>iso4217:USD<',b'>iso4217:EUR<'),
    (b'>0000320193<',b'>0000000001<'),
    (b'contextRef="quarter"',b'contextRef="absent"'),
    (b'<dei:DocumentFiscalYearFocus contextRef="annual">2019',b'<dei:DocumentFiscalYearFocus contextRef="annual">2020'),
    (b'<dei:DocumentType contextRef="annual">10-K</dei:DocumentType>',b''),
])
def test_bad_evidence_cannot_pass(before,after):
    assert mod.audit(fixture().replace(before,after))['linkage']!='PASS'


def test_conflicting_duplicate_revenue():
    source=fixture()
    extra=b'<us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax contextRef="annual" unitRef="USD">260175000000</us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax>'
    result=mod.audit(source.replace(b'</xbrli:xbrl>',extra+b'</xbrli:xbrl>'))
    assert result['linkage']=='CONTRADICTED'
    assert result['counts']['revenue_candidates']==3


def test_conflicting_dei():
    source=fixture()
    extra=b'<dei:DocumentFiscalYearFocus contextRef="annual">2020</dei:DocumentFiscalYearFocus>'
    assert mod.audit(source.replace(b'</xbrli:xbrl>',extra+b'</xbrli:xbrl>'))['linkage']=='CONTRADICTED'


@pytest.mark.parametrize('before,after',[
    (b'ixt:numdotdecimal',b'ixt:unknown'),
    (b'scale="6"',b'scale="19"'),
    (b'decimals="-6"',b'decimals="-6" continuedAt="x"'),
    (b'<html ',b'<!DOCTYPE html><html '),
    (b'</html>',b'</broken>'),
])
def test_inline_unsupported(before,after):
    assert mod.audit(fixture(True).replace(before,after))['linkage']=='UNSUPPORTED'


def test_missing_representation_and_header_mismatch():
    assert mod.audit(b'<DOCUMENT><TYPE>EX-99\n<FILENAME>x.txt\n<TEXT>hello</TEXT></DOCUMENT>')['linkage']=='UNSUPPORTED'
    assert mod.audit(fixture().replace(b'ACCESSION NUMBER: 0000320193-19-000119',b'ACCESSION NUMBER: wrong'))['linkage']=='CONTRADICTED'


def test_english_dei_inline():
    source=fixture(True).replace(b'<dei:DocumentPeriodEndDate contextRef="annual">2019-09-28</dei:DocumentPeriodEndDate>',b'<ix:nonNumeric name="dei:DocumentPeriodEndDate" contextRef="annual" format="ixt:datemonthdayyearen">September 28, 2019</ix:nonNumeric>')
    assert mod.audit(source)['linkage']=='PASS'


def test_no_network(monkeypatch):
    import socket
    monkeypatch.setattr(socket,'socket',lambda *a,**kw: pytest.fail('network attempted'))
    assert mod.audit(fixture())['linkage']=='PASS'


def test_dimensioned_disaggregation_is_preserved_but_not_admitted():
    source=fixture()
    context=b'<xbrli:context id="segment"><xbrli:entity><xbrli:identifier scheme="http://www.sec.gov/CIK">0000320193</xbrli:identifier><xbrli:segment><explicitMember>SegmentA</explicitMember></xbrli:segment></xbrli:entity><xbrli:period><xbrli:startDate>2018-09-30</xbrli:startDate><xbrli:endDate>2019-09-28</xbrli:endDate></xbrli:period></xbrli:context>'
    fact=b'<us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax contextRef="segment" unitRef="USD">1000000000</us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax>'
    result=mod.audit(source.replace(b'</xbrli:xbrl>',context+fact+b'</xbrli:xbrl>'))
    assert result['linkage']=='PASS',result
    assert result['counts']['revenue_candidates']==3
    assert result['documents'][0]['facts'][-1]['admitted'] is False


def test_exact_large_decimal_does_not_round_to_expected_value():
    source=fixture(True).replace(b'scale="6"',b'scale="0"').replace(b'260,174',b'260174000000.00000000000000001').replace(b'64,040',b'64040000000')
    assert mod.audit(source)['linkage']=='CONTRADICTED'


from fractions import Fraction
from decimal import Decimal
from hypothesis import given, settings, strategies as st


@given(st.integers(min_value=1,max_value=10**50),st.integers(min_value=0,max_value=20),st.integers(min_value=-18,max_value=18),st.booleans(),st.booleans())
@settings(max_examples=80,deadline=None)
def test_inline_scale_is_exact_rational(coefficient,places,scale,minus,grouped):
    digits=str(coefficient).zfill(places+1)
    integer=digits[:-places] if places else digits
    fraction=digits[-places:] if places else ''
    display=(format(int(integer),',') if grouped else integer)+('.'+fraction if places else '')
    source=fixture(True).replace(b'260,174',display.encode()).replace(b'scale="6"',f'scale="{scale}"'.encode())
    if minus:
        source=source.replace(b'name="us-gaap:',b'sign="-" name="us-gaap:')
    result=mod.audit(source)
    value=Decimal(result['documents'][0]['facts'][0]['value'])
    actual=Fraction(*value.as_integer_ratio())
    expected=Fraction(coefficient,10**places)*Fraction(10**scale if scale>=0 else 1,1 if scale>=0 else 10**(-scale))*(-1 if minus else 1)
    assert actual==expected


def test_exact_sgml_xbrl_wrapper_preserves_inventory_body():
    source=fixture().replace(b'<xbrli:xbrl ',b'<XBRL>\n<?xml version="1.0" encoding="UTF-8"?>\n<xbrli:xbrl ').replace(b'</xbrli:xbrl>',b'</xbrli:xbrl>\n</XBRL>')
    result=mod.audit(source)
    assert result['linkage']=='PASS',result
    assert result['inventory'][0]['body_bytes']>mod.audit(fixture())['inventory'][0]['body_bytes']
    assert result['documents'][0]['sgml_xbrl_wrapper'] is True


@pytest.mark.parametrize('dei',[False,True])
def test_inline_excluded_text_never_manufactures_expected_value(dei):
    source=fixture(True)
    if dei:
        source=source.replace(b'<dei:DocumentType contextRef="annual">10-K</dei:DocumentType>',b'<ix:nonNumeric name="dei:DocumentType" contextRef="annual">10<ix:exclude>-K</ix:exclude></ix:nonNumeric>')
    else:
        source=source.replace(b'260,174',b'260,<ix:exclude>174</ix:exclude>')
    assert mod.audit(source)['linkage']=='UNSUPPORTED'


@pytest.mark.parametrize('field',[b'FILED AS OF DATE: 20191031\n',b'DATE AS OF CHANGE: 20191031\n',b'<ACCEPTANCE-DATETIME>20191030181236\n'])
def test_missing_header_availability_is_explicitly_unsupported(field):
    assert mod.audit(fixture().replace(field,b''))['linkage']=='UNSUPPORTED'


def test_standalone_must_have_actual_xbrl_root():
    source=fixture().replace(b'<xbrli:xbrl ',b'<arbitrary ').replace(b'</xbrli:xbrl>',b'</arbitrary>')
    assert mod.audit(source)['linkage']=='UNSUPPORTED'
