"""Offline-only acquisition controls; never call registered source/root."""

import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

import httpx
import pytest


@pytest.fixture
def api():
    script = Path(
        os.environ.get(
            "QF_CAPTURE420_SCRIPT", Path(__file__).with_name("qf-w45-s5-capture420.py")
        )
    )
    spec = importlib.util.spec_from_file_location("capture420", script)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod


def setup(tmp_path):
    protocol = tmp_path / "protocol.md"
    protocol.write_text("offline frozen test protocol\n")
    return (
        protocol,
        hashlib.sha256(protocol.read_bytes()).hexdigest(),
        tmp_path / "exclusive",
    )


def run(api, tmp_path, handler, **kwargs):
    protocol, sha, root = setup(tmp_path)
    receipt = api.capture(
        root, protocol, sha, transport=httpx.MockTransport(handler), **kwargs
    )
    return root, receipt


def test_one_get_bytes_binding_and_deterministic_gzip(api, tmp_path):
    requests = []

    def handler(request):
        requests.append(request)
        root = tmp_path / "exclusive"
        start = json.loads((root / "START.json").read_text())
        assert start["source"]["url"] == api.URL
        assert (
            start["protocol_sha256"]
            == hashlib.sha256((tmp_path / "protocol.md").read_bytes()).hexdigest()
        )
        assert (
            start["script_sha256"]
            == hashlib.sha256(Path(api.__file__).read_bytes()).hexdigest()
        )
        assert start["httpx_version"] == httpx.__version__
        assert (
            len(start["httpx_module_sha256"]) == 64 and len(start["git_revision"]) == 40
        )
        return httpx.Response(
            200,
            content=b"\x00submission\xff",
            headers={"content-type": "text/plain", "date": "testdate"},
        )

    root, receipt = run(api, tmp_path, handler)
    assert len(requests) == 1 and requests[0].method == "GET"
    assert str(requests[0].url) == api.URL
    assert requests[0].headers["User-Agent"] == api.USER_AGENT
    assert requests[0].headers["Accept-Encoding"] == "identity"
    assert receipt["acquisition_status"] == "CAPTURED"
    assert receipt["scientific_status"] == "NOT_AUDITED"
    assert receipt["raw_byte_count"] == 12
    assert (
        receipt["raw_sha256"]
        == hashlib.sha256((root / "response.raw").read_bytes()).hexdigest()
    )
    assert (
        gzip.decompress((root / "response.raw.gz").read_bytes())
        == b"\x00submission\xff"
    )
    assert (root / "response.raw.gz").read_bytes() == gzip.compress(
        b"\x00submission\xff", mtime=0
    )
    assert (
        receipt["gzip_sha256"]
        == hashlib.sha256((root / "response.raw.gz").read_bytes()).hexdigest()
    )
    assert (root / "protocol.md").read_bytes() == (
        tmp_path / "protocol.md"
    ).read_bytes()
    assert (root / "RESULT.json").exists()


@pytest.mark.parametrize("status", [403, 404, 500, 302])
def test_non200_and_redirect_terminal_no_second_request(api, tmp_path, status):
    requests = []

    def handler(request):
        requests.append(request)
        return httpx.Response(
            status,
            content=b"blocked",
            headers={"Location": "https://example.invalid/elsewhere"},
        )

    root, receipt = run(api, tmp_path, handler)
    assert len(requests) == 1
    assert receipt["acquisition_status"] == "UNEVALUABLE"
    assert receipt["http_status"] == status
    assert receipt["final_url"] == api.URL
    assert (root / "response.raw").read_bytes() == b"blocked"


def test_empty_body_is_terminal(api, tmp_path):
    _, receipt = run(api, tmp_path, lambda _: httpx.Response(200, content=b""))
    assert receipt["acquisition_status"] == "UNEVALUABLE"
    assert receipt["reason"] == "empty_body"


def test_exact_cap_and_oversize_retain_bounded_actual_bytes(api, tmp_path):
    root, receipt = run(
        api, tmp_path, lambda _: httpx.Response(200, content=b"123456"), max_body=5
    )
    assert (
        receipt["acquisition_status"] == "UNEVALUABLE"
        and receipt["reason"] == "body_limit"
    )
    assert (root / "response.raw").read_bytes() == b"12345"
    assert receipt["raw_byte_count"] == 5 and receipt["observed_decoded_bytes"] == 6
    assert receipt["raw_sha256"] == hashlib.sha256(b"12345").hexdigest()


class BrokenStream(httpx.SyncByteStream):
    def __iter__(self):
        yield b"partial"
        raise httpx.ReadTimeout("simulated timeout")


def test_socket_failure_preserves_partial_bytes_no_retry(api, tmp_path):
    requests = []

    def handler(request):
        requests.append(request)
        return httpx.Response(200, stream=BrokenStream())

    root, receipt = run(api, tmp_path, handler)
    assert len(requests) == 1
    assert receipt["acquisition_status"] == "UNEVALUABLE"
    assert receipt["exception_type"] == "ReadTimeout"
    assert (root / "response.raw").read_bytes() == b"partial"
    assert receipt["raw_sha256"] == hashlib.sha256(b"partial").hexdigest()


def test_connect_exception_records_zero_bytes(api, tmp_path):
    requests = []

    def handler(request):
        requests.append(request)
        raise httpx.ConnectError("simulated connect failure")

    root, receipt = run(api, tmp_path, handler)
    assert len(requests) == 1 and receipt["raw_byte_count"] == 0
    assert receipt["exception_type"] == "ConnectError"
    assert receipt["http_status"] is None
    assert (root / "START.json").exists() and (root / "RESULT.json").exists()


def test_existing_interrupted_start_refuses_before_transport(api, tmp_path):
    protocol, sha, root = setup(tmp_path)
    root.mkdir()
    (root / "START.json").write_text("original interrupted marker")

    def handler(_):
        raise AssertionError("forbidden retry")

    with pytest.raises(FileExistsError):
        api.capture(root, protocol, sha, transport=httpx.MockTransport(handler))
    assert (root / "START.json").read_text() == "original interrupted marker"
    assert not (root / "RESULT.json").exists()


def test_changed_protocol_refuses_before_root_or_transport(api, tmp_path):
    protocol, sha, root = setup(tmp_path)
    protocol.write_text("changed")
    with pytest.raises(ValueError, match="protocol"):
        api.capture(
            root,
            protocol,
            sha,
            transport=httpx.MockTransport(lambda _: pytest.fail("network")),
        )
    assert not root.exists()


def test_elapsed_ceiling_preserves_bytes_and_stops(api, tmp_path):
    ticks = iter([0.0, 1.0, 62.0, 63.0])
    root, receipt = run(
        api,
        tmp_path,
        lambda _: httpx.Response(200, content=b"body"),
        clock=lambda: next(ticks),
    )
    assert (
        receipt["acquisition_status"] == "UNEVALUABLE"
        and receipt["reason"] == "elapsed_limit"
    )
    assert receipt["elapsed_seconds"] >= 60


def test_interrupted_stream_keeps_start_and_partial_without_false_result(api, tmp_path):
    class Interrupted(httpx.SyncByteStream):
        def __iter__(self):
            yield b"partial"
            raise KeyboardInterrupt()

    protocol, sha, root = setup(tmp_path)
    with pytest.raises(KeyboardInterrupt):
        api.capture(
            root,
            protocol,
            sha,
            transport=httpx.MockTransport(
                lambda _: httpx.Response(200, stream=Interrupted())
            ),
        )
    assert (root / "START.json").exists()
    assert (root / "response.raw").read_bytes() == b"partial"
    assert not (root / "RESULT.json").exists()


def test_late_received_chunk_is_retained_before_elapsed_stop(api, tmp_path):
    ticks = iter([0.0, 61.0, 62.0])
    calls = []

    def handler(request):
        calls.append(request)
        return httpx.Response(200, content=b"late")

    root, receipt = run(api, tmp_path, handler, clock=lambda: next(ticks))
    assert len(calls) == 1
    assert receipt["reason"] == "elapsed_limit"
    assert (root / "response.raw").read_bytes() == b"late"
    assert receipt["raw_byte_count"] == 4 and receipt["observed_decoded_bytes"] == 4


def test_reaching_exact_cap_is_terminal(api, tmp_path):
    root, receipt = run(
        api, tmp_path, lambda _: httpx.Response(200, content=b"12345"), max_body=5
    )
    assert (
        receipt["reason"] == "body_limit"
        and receipt["acquisition_status"] == "UNEVALUABLE"
    )
    assert (root / "response.raw").read_bytes() == b"12345"
    assert receipt["raw_byte_count"] == receipt["observed_decoded_bytes"] == 5


def test_real_client_transport_configuration_has_no_env_redirect_or_retry(
    api, tmp_path, monkeypatch
):
    original_client = httpx.Client
    seen = {}
    calls = []

    def handler(request):
        calls.append(request)
        assert "Authorization" not in request.headers
        assert request.extensions["timeout"] == {
            "connect": 10.0,
            "read": 15.0,
            "write": 15.0,
            "pool": 10.0,
        }
        return httpx.Response(200, content=b"offline")

    def transport(**kwargs):
        seen["transport"] = kwargs
        return httpx.MockTransport(handler)

    def client(**kwargs):
        seen["client"] = kwargs
        return original_client(**kwargs)

    monkeypatch.setattr(httpx, "HTTPTransport", transport)
    monkeypatch.setattr(httpx, "Client", client)
    protocol, sha, root = setup(tmp_path)
    api.capture(root, protocol, sha)
    assert seen["transport"] == {"retries": 0, "trust_env": False}
    assert seen["client"]["trust_env"] is False
    assert seen["client"]["follow_redirects"] is False
    assert seen["client"]["auth"] is None
    assert len(calls) == 1


def test_http_request_timestamp_distinct_from_invocation_start(
    api, tmp_path, monkeypatch
):
    stamps = iter(
        [
            "2026-11-06T00:00:00+00:00",
            "2026-11-06T00:00:01+00:00",
            "2026-11-06T00:00:02+00:00",
        ]
    )
    monkeypatch.setattr(api, "utc_now", lambda: next(stamps))
    root, receipt = run(
        api, tmp_path, lambda _: httpx.Response(200, content=b"offline")
    )
    start = json.loads((root / "START.json").read_text())
    assert start["request_started_at_utc"] == "2026-11-06T00:00:00+00:00"
    assert receipt["http_request_started_at_utc"] == "2026-11-06T00:00:01+00:00"
    assert receipt["request_completed_at_utc"] == "2026-11-06T00:00:02+00:00"
