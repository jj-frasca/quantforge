import gzip, hashlib, json, re, tarfile, types, subprocess
from datetime import datetime
from decimal import Decimal
from pathlib import Path
root=Path('/Users/joefrasca/claude-work/quantforge-codex')
source=Path('/tmp/qf-w45-s5-original-aapl2019')
portable=root/'docs/evidence/FINDING-322/AAPL-2019-original-filing'
def sha(raw): return hashlib.sha256(raw).hexdigest()
pre=json.loads((portable/'PREACQUISITION.json').read_bytes())
start=json.loads((portable/'START.json').read_bytes())
result=json.loads((portable/'RESULT.json').read_bytes())
assert start==json.loads((source/'START.json').read_bytes())
assert result==json.loads((source/'RESULT.json').read_bytes())
raw=(source/'response.raw').read_bytes(); compressed=(source/'response.raw.gz').read_bytes()
assert len(raw)==result['raw_byte_count']==result['observed_decoded_bytes']==12861616
assert sha(raw)==result['raw_sha256']=='c77a7ab405b61398dcbd7b0ecb98191b24c9519d9b18689c280c2ac7e4ebf4ab'
assert sha(compressed)==result['gzip_sha256'] and len(compressed)==result['gzip_byte_count']
assert gzip.decompress(compressed)==raw and compressed==gzip.compress(raw,mtime=0)
assert result['http_status']==200 and result['acquisition_status']=='CAPTURED' and result['partial_body'] is False
assert result['exception_type'] is None and result['scientific_status']=='NOT_AUDITED'
assert result['final_url']==result['source']['url']==pre['source']
assert result['git_revision']==pre['git_base']==start['git_revision']
protocol=(root/'docs/adr/ADR-420-freeze-one-original-filing-context-witness.md').read_bytes()
assert sha(protocol)==result['protocol_sha256']==pre['protocol_sha256']==sha((source/'protocol.md').read_bytes())
assert sha((source/'capture-script.py').read_bytes())==result['script_sha256']==pre['files']['qf-w45-s5-capture420.py']['sha256']
assert sha(Path(result['httpx_module_path']).read_bytes())==result['httpx_module_sha256']
assert sha((root/'backend/uv.lock').read_bytes())==result['uv_lock_sha256']
assert datetime.fromisoformat(pre['frozen_at_utc'])<datetime.fromisoformat(result['request_started_at_utc'])<datetime.fromisoformat(result['http_request_started_at_utc'])<datetime.fromisoformat(result['request_completed_at_utc'])
with tarfile.open(portable/'method.tar.gz','r:gz') as archive:
    files={m.name:archive.extractfile(m).read() for m in archive.getmembers() if m.isfile()}
assert set(files)==set(pre['files'])
for name,value in files.items():
    assert len(value)==pre['files'][name]['bytes'] and sha(value)==pre['files'][name]['sha256']
audit=types.ModuleType('_frozen_audit420_data'); exec(compile(files['qf-w45-s5-audit420.py'],'frozenaudit420','exec'),audit.__dict__)
actual=json.loads(json.dumps(audit.audit(raw)))
recorded=json.loads(gzip.decompress((portable/'AUDIT.json.gz').read_bytes()))
assert actual==recorded and actual['linkage']=='PASS' and not actual['reasons']
assert actual['counts']=={'documents':96,'revenue_candidates':62,'dei_candidates':4}
assert actual['representation']=='inline'
inventory=json.loads((portable/'INVENTORY.json').read_bytes())
assert inventory==actual['inventory']
component_manifest=json.loads((portable/'COMPONENTS.json').read_bytes())
blocks=list(re.finditer(br'<DOCUMENT>(.*?)</DOCUMENT>',raw,re.S|re.I))
expectedparts={'submission-header.raw.gz':raw[:blocks[0].start()], 'submission-footer.raw.gz':raw[blocks[-1].end():]}
for entry in actual['inventory']:
    if entry['type'] in ('10-K','EX-101.INS'):
        expectedparts[f"document-{entry['index']:03d}.{entry['type'].lower()}.sgml.gz"]=blocks[entry['index']].group(0)
assert len(expectedparts)==3 and len(component_manifest['components'])==3
for entry in component_manifest['components']:
    packed=(portable/entry['file']).read_bytes(); part=gzip.decompress(packed)
    assert part==expectedparts[entry['file']] and len(part)==entry['raw_bytes'] and sha(part)==entry['raw_sha256']
    assert packed[4:8]==bytes(4) and packed[3]==0 and len(packed)==entry['gzip_bytes'] and sha(packed)==entry['gzip_sha256']
    assert len(packed)<450*1024
assert component_manifest['full_source_raw_sha256']==sha(raw) and component_manifest['inventory_document_count']==96 and not component_manifest['not_portable']
portable_source=expectedparts['submission-header.raw.gz']+expectedparts['document-000.10-k.sgml.gz']+expectedparts['submission-footer.raw.gz']
reproduced=json.loads(json.dumps(audit.audit(portable_source)))
assert reproduced['linkage']=='PASS' and reproduced['documents']==actual['documents'] and reproduced['header']==actual['header']
assert reproduced['counts']=={'documents':1,'revenue_candidates':62,'dei_candidates':4}
doc=actual['documents'][0]
assert len(doc['contexts'])==301 and len(doc['units'])==9
summary=[]
for period,want in [(('2018-09-30','2019-09-28'),'260174000000'),(('2019-06-30','2019-09-28'),'64040000000')]:
    matches=[f for f in doc['facts'] if f['admitted'] and (doc['contexts'][f['contextRef']]['starts'],doc['contexts'][f['contextRef']]['ends'])==([period[0]],[period[1]])]
    assert matches and {Decimal(f['value']) for f in matches}=={Decimal(want)}
    assert all(f['unit_valid'] and f['context_valid'] for f in matches)
    summary.append({'period':period,'value':want,'count':len(matches),'contexts':sorted(set(f['contextRef'] for f in matches))})
assert actual['header']['acceptance_raw']=='20191030181236' and actual['header']['filed']==['20191031'] and actual['header']['changed']==['20191030']
protected=subprocess.check_output(['git','ls-files','docs/evidence/FINDING-351','docs/evidence/ADR-418','docs/evidence/FINDING-322/companyfacts.CIK0000320193.20261030.json.gz','docs/evidence/FINDING-322/companyfacts.CIK0000789019.20261030.json.gz'],cwd=root,text=True).splitlines()
for path in protected: assert (root/path).read_bytes()==subprocess.check_output(['git','show','HEAD:'+path],cwd=root)
print(json.dumps({'verdict':'PASS','raw_sha256':sha(raw),'portable_components':3,'inventory':96,'contexts':301,'units':9,'revenue_candidates':62,'dei':4,'witnesses':summary,'frozen_protected_files_exact':len(protected)},indent=2))
