import gzip, hashlib, importlib.util, io, json, re, tarfile
from fractions import Fraction
from pathlib import Path
from xml.etree import ElementTree as E
repo=Path('/Users/joefrasca/claude-work/quantforge-codex')
folder=repo/'docs/evidence/FINDING-322/AAPL-2019-original-filing'
root=Path('/tmp/qf-w45-s5-original-aapl2019')
sha=lambda b:hashlib.sha256(b).hexdigest()
receipt=json.loads((folder/'RESULT.json').read_bytes())
start=json.loads((folder/'START.json').read_bytes())
pre=json.loads((folder/'PREACQUISITION.json').read_bytes())
manifest=json.loads((folder/'COMPONENTS.json').read_bytes())
raw=(root/'response.raw').read_bytes()
assert len(raw)==12861616 and sha(raw)==receipt['raw_sha256']==manifest['full_source_raw_sha256']
assert gzip.decompress((root/'response.raw.gz').read_bytes())==raw
assert sha((root/'response.raw.gz').read_bytes())==receipt['gzip_sha256']
assert receipt['http_status']==200 and receipt['acquisition_status']=='CAPTURED' and not receipt['partial_body']
assert pre['source_attempts_before_freeze']==0 and pre['root_absent']
assert pre['frozen_at_utc']<receipt['http_request_started_at_utc']
assert start['protocol_sha256']==receipt['protocol_sha256']==pre['protocol_sha256']==sha((root/'protocol.md').read_bytes())==sha((repo/'docs/adr/ADR-420-freeze-one-original-filing-context-witness.md').read_bytes())
assert start['script_sha256']==receipt['script_sha256']==sha((root/'capture-script.py').read_bytes())
assert (folder/'START.json').read_bytes()==(root/'START.json').read_bytes()
assert (folder/'RESULT.json').read_bytes()==(root/'RESULT.json').read_bytes()
with tarfile.open(folder/'method.tar.gz','r:gz') as archive:
    contents={m.name:archive.extractfile(m).read() for m in archive.getmembers() if m.isfile()}
    for filename,expected in pre['files'].items():
        matches=[v for k,v in contents.items() if k.split('/')[-1]==filename]
        assert len(matches)==1,filename
        assert len(matches[0])==expected['bytes'] and sha(matches[0])==expected['sha256'],filename
    audit_bytes=next(v for k,v in contents.items() if k.split('/')[-1]=='qf-w45-s5-audit420.py')
    assert sha(audit_bytes)=='706dbda5528bc8af36883d7a5705c25f2612f10c46824343ad0b05b55faeae6f'
for component in manifest['components']:
    compressed=(folder/component['file']).read_bytes(); expanded=gzip.decompress(compressed)
    assert len(compressed)==component['gzip_bytes'] and sha(compressed)==component['gzip_sha256']
    assert len(expanded)==component['raw_bytes'] and sha(expanded)==component['raw_sha256']
    assert expanded in raw
    assert len(compressed)<=450*1024
print('complete source/transport/protocol/script/preacquisition archive/component hashes PASS')
# Frozen method reproduction (no source acquisition module is invoked).
spec=importlib.util.spec_from_file_location('frozen420','/tmp/qf-w45-s5-audit420.py'); mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
assert sha(Path(mod.__file__).read_bytes())==sha(audit_bytes)
actual=mod.audit(raw)
stored=json.loads(gzip.decompress((folder/'AUDIT.json.gz').read_bytes()))
# tuples serialize as lists in JSON
assert json.loads(json.dumps(actual))==stored
assert actual['linkage']=='PASS' and len(actual['inventory'])==96
parts={c['file']:gzip.decompress((folder/c['file']).read_bytes()) for c in manifest['components']}
portable=parts['submission-header.raw.gz']+parts['document-000.10-k.sgml.gz']+parts['submission-footer.raw.gz']
portable_result=mod.audit(portable)
assert portable_result['linkage']=='PASS'
assert json.loads(json.dumps(portable_result['documents']))==stored['documents']
assert json.loads((folder/'INVENTORY.json').read_bytes())==stored['inventory']
print('frozen method/full-source audit EXACT; portable component audit PASS and complete document graph EXACT')
# Independent parsing/context resolution and rational scaling oracle.
primary=parts['document-000.10-k.sgml.gz']
body=re.search(br'<TEXT>\s*(.*?)\s*</TEXT>',primary,re.S).group(1)
assert body.startswith(b'<XBRL>') and body.rstrip().endswith(b'</XBRL>')
body=body[len(b'<XBRL>'):body.rfind(b'</XBRL>')].strip()
namespaces={prefix:uri for _,(prefix,uri) in E.iterparse(io.BytesIO(body),events=['start-ns'])}
tree=E.fromstring(body)
x='{http://www.xbrl.org/2003/instance}'
ix='{http://www.xbrl.org/2013/inlineXBRL}'
contexts={node.get('id'):node for node in tree.iter(x+'context')}
units={node.get('id'):node for node in tree.iter(x+'unit')}
assert len(contexts)==301 and len(units)==9
witnesses=[]
for fact in tree.iter(ix+'nonFraction'):
    name=fact.get('name','')
    if not name.endswith(':RevenueFromContractWithCustomerExcludingAssessedTax'):continue
    context=contexts[fact.get('contextRef')]
    periods=(context.findtext(x+'period/'+x+'startDate'),context.findtext(x+'period/'+x+'endDate'))
    if periods not in [('2018-09-30','2019-09-28'),('2019-06-30','2019-09-28')]:continue
    if any(n.tag.endswith('}segment') or n.tag.endswith('}scenario') for n in context.iter()):continue
    ident=context.find(x+'entity/'+x+'identifier')
    assert ident.text=='0000320193' and ident.get('scheme')=='http://www.sec.gov/CIK'
    unit=units[fact.get('unitRef')]
    measure=unit.find(x+'measure').text
    prefix,local=measure.split(':')
    assert namespaces[prefix]=='http://www.xbrl.org/2003/iso4217' and local=='USD'
    assert not any(n.tag==ix+'exclude' for n in fact.iter())
    lexical=''.join(fact.itertext()).strip().replace(',','')
    sign=-1 if lexical.startswith('-') else 1
    lexical=lexical.lstrip('+-')
    integer,_,fraction=lexical.partition('.')
    unscaled=Fraction(int(integer+fraction),10**len(fraction))*sign
    exponent=int(fact.get('scale','0'))
    scaled=unscaled*Fraction(10**exponent if exponent>=0 else 1,1 if exponent>=0 else 10**(-exponent))*(-1 if fact.get('sign')=='-' else 1)
    expected=260174000000 if periods[0]=='2018-09-30' else 64040000000
    assert scaled==expected
    witnesses.append((fact.get('id'),fact.get('contextRef'),fact.get('unitRef'),str(scaled),periods,fact.get('scale'),fact.get('format')))
assert len(witnesses)==4
assert len(set((w[3],w[4]) for w in witnesses))==2
print('independent integer/Fraction original inline facts:',witnesses)
for fact in tree.iter(ix+'nonNumeric'):
    if fact.get('name','').split(':')[-1] not in {'DocumentType','DocumentPeriodEndDate','DocumentFiscalYearFocus','DocumentFiscalPeriodFocus'}:continue
    context=contexts[fact.get('contextRef')]
    assert (context.findtext(x+'period/'+x+'startDate'),context.findtext(x+'period/'+x+'endDate'))==('2018-09-30','2019-09-28')
    print('DEI',fact.get('name'),repr(''.join(fact.itertext()).strip()),fact.get('contextRef'),fact.get('format'))
print('header',actual['header'])
print('ALL OFFLINE RESULT CHECKS PASS; zero source requests, prices, scorers, searches or market outcomes')
