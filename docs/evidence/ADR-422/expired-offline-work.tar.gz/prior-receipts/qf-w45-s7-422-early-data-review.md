# ADR422 early structural review — NOT final approval

Text-only review of the initial scratch implementation while its builder's focused
run was active. No imports, tests, network, target source, cohort root or product
files touched. All findings sent promptly to parent and builder; final source is
still changing, so this is not a frozen-code review or execution receipt.

## Blockers found before source exposure

1. Request-count exhaustion was checked during every post-stage budget check.
   A successful fifth issuer's twentieth CompanyFacts GET would assemble and then
   raise before its terminal receipt, making an otherwise complete study
   INCOMPLETE. Separate the before-next-GET count barrier from post-stage time/
   byte checks. Require an all-five/all-twenty successful mock trace before fix.
2. English date mapping used calendar.month_name/month_abbr, runtime locale
   proxies, contrary to the explicit no-ambient-locale contract. Freeze literal
   English month names/abbreviations; adversarial locale proxy control first.
3. Context extraction used descendant searches for identifier/start/end, allowing
   structurally misplaced descendants or duration-plus-forever to masquerade as
   an admitted annual context. Require direct entity/period shape and exact
   duration choice; test wrong placement and forever-plus-duration refusal.
4. Complete submission was globally UTF8-decoded only to find its SEC header,
   potentially rejecting an otherwise supported primary because of unrelated
   nonUTF8 exhibit content. The declared domain is primary-only XML. Extract
   header boundaries from bytes, decode that header only, and parse native primary
   XML bytes. Do not parse unrelated exhibits or borrow their namespace evidence.

## Additional conformance checks/questions

- A DEI namespace startswith check admits fake/ambiguous suffixes. Freeze recognized
  exact year/date namespace grammar and test spoofed suffixes before acquisition.
- Legacy parser refusal was coupled to anchored coverage failure. ADR422's strict
  acceptance concerns supported anchors/all13 financial outputs/existing quality
  consumption; legacy comparison is diagnostic. Resolve before targets whether a
  legacy refusal is retained as an explicit comparison REFUSED status while
  anchored evidence remains evaluable, instead of silently adding an unstated
  admission condition. No actual target or incidence evidence prompted this.
- PREACQUISITION should be durably bound/preserved alongside START, not merely
  approvals read from an external mutable file. Final exact code/protocol/tests/
  dependencies/roster identity and independent review receipts remain required.
- Review complete inventory balance checks and primary-only representation support
  in final code. Full source/body hashes and complete primary component hashes are
  distinct and must retain explicit semantics.

No source criterion is being relaxed after outcomes: no target content has been
acquired. All fixes need original RED controls and full independent final review
before the sole live invocation. Period coverage remains conditional source-claim
alignment, not historical PIT, cross-year EPS/share split-basis comparability,
issuer truth, value or alpha.
