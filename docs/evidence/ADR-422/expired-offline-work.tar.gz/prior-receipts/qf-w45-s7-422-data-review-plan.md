# ADR-422 independent data conformance plan

Scope: read-only preimplementation preparation. Read ADR-422, ADR-421, ADR-420,
current data contracts, fixed roster, retained original component hashes and
ADR-421's separate annual/transition cover receipt. No target content, HTTP,
cohort root, imports or implementation created. No blocking protocol defect found.

## Release prerequisites

- Exact live root absent; fixed CLI root and start-before 2026-11-07T11:00Z.
  Tests use injected temporary paths without a live transport. Importing the method
  or invoking it without the explicit live action cannot create the cohort root.
- Actual collected RED precedes implementation. Final source/tests/protocol/roster,
  executed revision, installed httpx/lxml versions/module hashes and app421 identity
  are frozen in parent-reviewed PREACQUISITION and durable START before first GET.
- Both chosen original submissions rows are durable before either filing request.
  Issuer identity binds path/submissions/header/context. Accession is independently
  exact; its numeric prefix may identify a filing agent and must not be equated
  with issuer CIK. No undisclosed alternate accession or earlier-filings API.

## Independent oracle cases

1. Retained positive: complete existing primary Apple 2019 component plus header
   parses to FY2019, 2018-09-30..2019-09-28, annual true / transition false. Verify
   original primary raw SHA7941574d...976be82 and the six original DEI nodes/context
   against prior immutable evidence; do not use known revenue amounts as a parser
   requirement. Reconstructing a thin submission changes whole-body hash/inventory
   and must not be passed off as the original full source.
2. Synthetic DEI oracle: non-December year, filing-agent accession prefix, two
   equal duplicate facts, local namespace shadowing, unknown transform even with
   superficially plausible text, conflicting duplicate, missing/instant-only flag,
   nil/continuedAt/exclude, dimensional/scenario context, wrong CIK scheme/issuer,
   repeated/missing context IDs, header/reportDate/type/accession mismatch. Do not
   infer starts, fiscal labels or transition false. Date/checkbox interpretation
   must follow exact predeclared URI/local-name pairs and XML/SEC lexical forms.
3. Header/inventory isolation: inventory every complete SGML DOCUMENT and hash;
   choose exactly one primary10-K. Secure XML rejection applies to the selected
   financial representation; do not accidentally parse unrelated exhibits or use
   their namespace/doctype declarations as the primary's semantic evidence.
4. Submissions: same-length string arrays, exact10-K date validation before choice,
   unrelated empty reportDate allowed, duplicate accessions refused, deterministic
   filingDate/accession order, fewer than two refusal, older-then-newer requests.
5. Two-year accounting: exact same CompanyFacts bytes for both app421 wrappers;
   one issuer/distinct accessions/consecutive labels/prior_end+1day==next_start.
   Retain both wrappers and latest citation; max all actual source observations
   bounds eligibility. Existing quality scorer receives ordered two-year history;
   price/value/combined absent. Reject gap, overlap, repeated label and issuer
   mismatch. Check all13 financial outputs, not raw14concept count: direct GP can
   make COGS unnecessary, but FCF needs both aligned OCF and capex.
6. Transport recorder oracle: mock serial GET log and durable files establish
   20max/4perissuer/0.2s start separation, retries0/redirectsFalse/trust_envFalse,
   fixed UA, timeouts10/15/15/10, per-body64MiB and total256MiB retained limits,
   request60s and overall600s checks. Preserve partial/non200/redirect/exception
   status, observed versus retained bytes, UTC request/completion times, exact
   body SHA, gzip mtime0. Mock stream must record at most one provider invocation
   per planned source; fetch failures cannot invoke another URL or retry.
7. Control-flow recorder: first issuer failure stops its remaining requests but
   visits the next fixed issuer while budget permits. Overall expiry/cap stops
   further GETs, preserves the unresolved/planned state and marks INCOMPLETE with
   no partial success fraction. Existing root, elapsed cutoff and early invalid
   identity must prevent live fetch. Interrupted START cannot resume/re-root.

## Terminal result and packaging review

All five planned issuer attempts must terminate before any complete-denominator
coverage summary. Any issuer failure is overall coverageFAIL, never removed.
Unsupported source-domain, transport, missing fields, conflicts and continuity
remain distinct. A reviewer-detected implementation/method defect yields
UNEVALUABLE/INVALID_METHOD; preserve the attempt and never replay changed code.
Even all-five failure describes only this declared method/domain, not SEC-wide
availability. There are zero economic/configuration trials or return observations.

Inspect every full retained raw/gzip source and all hashes at root independently.
Portable files are complete JSON or complete header/primary components only when
individual gzip<=450KiB; no splitting or favorable row extraction to evade hooks.
Root-only bodies and lack of full public reproduction remain explicit, separately
from scientific coverage. Source-only status cannot become value, alpha or PIT
proof. ADR417/418 and all earlier source/timing roots remain untouched.

No preimplementation blocker. Final approval depends on actual code, adversarial
synthetic controls, original retained control, complete test receipts and exact
hash freeze before the sole parent invocation. This plan itself approves no HTTP.
