"""Offline ADR422 contracts; no target requests or registered study-root writes."""

from __future__ import annotations

import gzip
import importlib
import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import httpx
import pytest
from hypothesis import given
from hypothesis import strategies as st

HERE = Path(__file__).parent
REPO = Path("/Users/joefrasca/claude-work/quantforge-codex")
NOW = datetime(2026, 11, 7, 9, tzinfo=UTC)
ACC = "0009999999-25-000001"  # agent prefix deliberately differs from issuer


def api() -> Any:
    return importlib.import_module("coverage422")


def filing(
    cik: int = 123,
    accession: str = ACC,
    end: str = "2025-09-27",
    start: str = "2024-09-29",
    year: int = 2025,
    **changes: Any,
) -> bytes:
    context = f'<xbrli:context id="annual"><xbrli:entity><xbrli:identifier scheme="http://www.sec.gov/CIK">{cik}</xbrli:identifier></xbrli:entity><xbrli:period><xbrli:startDate>{start}</xbrli:startDate><xbrli:endDate>{end}</xbrli:endDate></xbrli:period></xbrli:context>'
    facts = {
        "DocumentType": "10-K",
        "DocumentFiscalPeriodFocus": "FY",
        "DocumentFiscalYearFocus": str(year),
        "DocumentPeriodEndDate": end,
        "DocumentAnnualReport": "true",
        "DocumentTransitionReport": "false",
    }
    facts.update(changes.pop("facts", {}))
    xml = f'<html xmlns="http://www.w3.org/1999/xhtml" xmlns:ix="http://www.xbrl.org/2013/inlineXBRL" xmlns:xbrli="http://www.xbrl.org/2003/instance" xmlns:dei="http://xbrl.sec.gov/dei/2025" xmlns:sec="http://www.sec.gov/inlineXBRL/transformation/2015-08-31"><body>{context}'
    for key, value in facts.items():
        if value is not None:
            xml += f'<ix:nonNumeric name="dei:{key}" contextRef="annual">{value}</ix:nonNumeric>'
    xml += "</body></html>"
    xml = changes.pop("xml", xml)
    header = f"<SEC-HEADER>\nACCESSION NUMBER: {accession}\nCONFORMED SUBMISSION TYPE: 10-K\nCENTRAL INDEX KEY: {cik:010d}\nCONFORMED PERIOD OF REPORT: {end.replace('-', '')}\nFILED AS OF DATE: 20251031\nDATE AS OF CHANGE: 20251031\n<ACCEPTANCE-DATETIME>20251031120000\n</SEC-HEADER>"
    assert not changes
    return (
        header
        + "\n<DOCUMENT>\n<TYPE>10-K\n<SEQUENCE>1\n<FILENAME>annual.htm\n<TEXT>"
        + xml
        + "</TEXT>\n</DOCUMENT>"
    ).encode()


def selected(accession: str = ACC, report: str = "2025-09-27") -> dict[str, str]:
    return {
        "accessionNumber": accession,
        "form": "10-K",
        "filingDate": "2025-10-31",
        "reportDate": report,
    }


def extract(raw: bytes | None = None, **changes: Any) -> Any:
    args = {
        "raw": raw or filing(),
        "cik": 123,
        "selected": selected(),
        "observed_at": NOW,
        "url": "original",
    }
    args.update(changes)
    return api().extract_anchor(**args)


def submissions(cik: int = 123) -> bytes:
    return json.dumps(
        {
            "cik": str(cik),
            "filings": {
                "recent": {
                    "accessionNumber": [
                        ACC,
                        "0009999999-24-000001",
                        "0009999999-25-000002",
                    ],
                    "form": ["10-K", "10-K", "8-K"],
                    "filingDate": ["2025-10-31", "2024-10-31", "2025-11-01"],
                    "reportDate": ["2025-09-27", "2024-09-28", ""],
                }
            },
        }
    ).encode()


def test_six_dei_anchor_binds_agent_accession_and_nondecember_period() -> None:
    result = extract()
    assert result["anchor"].annual_start.isoformat() == "2024-09-29"
    assert result["anchor"].cik == 123 and result["anchor"].transition is False
    assert len(result["audit"]["dei"]) == 6
    assert result["audit"]["inventory"][0]["type"] == "10-K"
    assert result["components"]["primary"] in filing()


def test_frozen_original420_supports_generic_six_dei_extraction() -> None:
    p = REPO / "docs/evidence/FINDING-322/AAPL-2019-original-filing"
    raw = (
        gzip.decompress((p / "submission-header.raw.gz").read_bytes())
        + gzip.decompress((p / "document-000.10-k.sgml.gz").read_bytes())
        + gzip.decompress((p / "submission-footer.raw.gz").read_bytes())
    )
    result = extract(
        raw, cik=320193, selected=selected("0000320193-19-000119", "2019-09-28")
    )
    assert result["anchor"].fiscal_year == 2019
    assert result["anchor"].annual_start.isoformat() == "2018-09-30"


@pytest.mark.parametrize(
    "concept",
    [
        "DocumentType",
        "DocumentFiscalPeriodFocus",
        "DocumentFiscalYearFocus",
        "DocumentPeriodEndDate",
        "DocumentAnnualReport",
        "DocumentTransitionReport",
    ],
)
def test_missing_required_dei_refuses(concept: str) -> None:
    with pytest.raises(api().StudyFailure):
        extract(filing(facts={concept: None}))


@pytest.mark.parametrize(
    "old,new",
    [
        (
            "<xbrli:startDate>2024-09-29</xbrli:startDate><xbrli:endDate>2025-09-27</xbrli:endDate>",
            "<xbrli:instant>2025-09-27</xbrli:instant>",
        ),
        ("http://www.sec.gov/CIK", "wrong-scheme"),
        (">123</xbrli:identifier>", ">124</xbrli:identifier>"),
        ("</xbrli:entity>", "<xbrli:segment/></xbrli:entity>"),
        ('name="dei:DocumentType"', 'name="dei:DocumentType" continuedAt="elsewhere"'),
        (
            'name="dei:DocumentType"',
            'name="dei:DocumentType" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:nil="true"',
        ),
        ('contextRef="annual">10-K', 'contextRef="absent">10-K'),
        (">false</ix:nonNumeric>", ">true</ix:nonNumeric>"),
        (
            'name="dei:DocumentPeriodEndDate"',
            'name="dei:DocumentPeriodEndDate" format="sec:unknown"',
        ),
        ('id="annual"', ""),
    ],
)
def test_unsupported_context_fact_or_transform_refuses(old: str, new: str) -> None:
    raw = filing()
    assert old.encode() in raw
    with pytest.raises(api().StudyFailure):
        extract(raw.replace(old.encode(), new.encode()))


def test_duplicate_context_and_conflicting_dei_refuse() -> None:
    raw = filing()
    context = raw[
        raw.index(b"<xbrli:context") : raw.index(b"</xbrli:context>")
        + len(b"</xbrli:context>")
    ]
    with pytest.raises(api().StudyFailure):
        extract(raw.replace(b"</body>", context + b"</body>"))
    with pytest.raises(api().StudyFailure):
        extract(
            raw.replace(
                b"</body>",
                b'<ix:nonNumeric name="dei:DocumentFiscalYearFocus" contextRef="annual">2024</ix:nonNumeric></body>',
            )
        )


@pytest.mark.parametrize("prefix", [b"<!DOCTYPE html>", b'<!ENTITY x "x">'])
def test_dtd_and_entity_declarations_refuse(prefix: bytes) -> None:
    with pytest.raises(api().StudyFailure):
        extract(filing().replace(b"<html ", prefix + b"<html "))


@pytest.mark.parametrize(
    "field,value",
    [
        ("cik", 124),
        ("selected", selected("0009999999-25-000002")),
        ("selected", selected(report="2025-09-28")),
    ],
)
def test_header_binding_refuses_mismatch(field: str, value: Any) -> None:
    with pytest.raises(api().StudyFailure):
        extract(**{field: value})


def test_submission_selection_allows_unrelated_empty_report_date() -> None:
    rows = api().select_filings(submissions(), 123)
    assert [r["accessionNumber"] for r in rows] == ["0009999999-24-000001", ACC]


@pytest.mark.parametrize(
    "mutation",
    ["arrays", "duplicate", "invalid_k_date", "invalid_type", "wrong_cik", "short"],
)
def test_submission_malformed_or_insufficient_refuses(mutation: str) -> None:
    data = json.loads(submissions())
    recent = data["filings"]["recent"]
    if mutation == "arrays":
        recent["form"].pop()
    elif mutation == "duplicate":
        recent["accessionNumber"][1] = ACC
    elif mutation == "invalid_k_date":
        recent["reportDate"][0] = ""
    elif mutation == "invalid_type":
        recent["form"][2] = None
    elif mutation == "wrong_cik":
        data["cik"] = "124"
    else:
        recent["form"][1] = "10-Q"
    with pytest.raises(api().StudyFailure):
        api().select_filings(json.dumps(data).encode(), 123)


@given(st.permutations([0, 1, 2]))
def test_submissions_order_does_not_choose_a_different_pair(order: list[int]) -> None:
    data = json.loads(submissions())
    recent = data["filings"]["recent"]
    data["filings"]["recent"] = {
        key: [values[i] for i in order] for key, values in recent.items()
    }
    assert api().select_filings(json.dumps(data).encode(), 123) == api().select_filings(
        submissions(), 123
    )


def test_run_all_five_terminal_http_failures_no_retries(tmp_path: Path) -> None:
    calls = []

    def reply(request: httpx.Request) -> httpx.Response:
        calls.append(str(request.url))
        assert (tmp_path / "study" / "START.json").exists()
        return httpx.Response(403, content=b"blocked")

    result = api().run_study(
        tmp_path / "study",
        api().identity_manifest(),
        transport=httpx.MockTransport(reply),
        now=lambda: NOW,
        sleep=lambda _: None,
    )
    assert (
        len(calls) == 5
        and result["status"] == "COMPLETE"
        and result["coverage"] == "FAIL"
    )
    assert len(result["issuers"]) == 5 and result["requests"] == 5
    assert all(x["status"] == "TRANSPORT_FAILURE" for x in result["issuers"])
    with pytest.raises(FileExistsError):
        api().run_study(
            tmp_path / "study",
            api().identity_manifest(),
            transport=httpx.MockTransport(reply),
            now=lambda: NOW,
            sleep=lambda _: None,
        )
    assert len(calls) == 5


def test_expiry_and_manifest_drift_make_no_root_or_http(tmp_path: Path) -> None:
    bad = api().identity_manifest()
    bad["code_sha256"] = "0" * 64
    with pytest.raises(ValueError):
        api().run_study(tmp_path / "bad", bad, now=lambda: NOW)
    with pytest.raises(ValueError):
        api().run_study(
            tmp_path / "expired",
            api().identity_manifest(),
            now=lambda: datetime(2026, 11, 7, 11, tzinfo=UTC),
        )
    assert not (tmp_path / "bad").exists() and not (tmp_path / "expired").exists()


def test_cohort_budget_stops_before_next_request_without_partial_fraction(
    tmp_path: Path,
) -> None:
    calls = []

    def reply(request: httpx.Request) -> httpx.Response:
        calls.append(str(request.url))
        return httpx.Response(200, content=b"x" * 30)

    result = api().run_study(
        tmp_path / "budget",
        api().identity_manifest(),
        transport=httpx.MockTransport(reply),
        limits=api().Limits(body_bytes=20, total_bytes=20),
        now=lambda: NOW,
        sleep=lambda _: None,
    )
    assert (
        len(calls) == 1
        and result["status"] == "INCOMPLETE"
        and result["coverage"] == "NOT_MEASURED"
    )
    assert result["retained_raw_bytes"] == 20
    assert "success_fraction" not in result


def test_exception_keeps_partial_source_and_terminal_receipt(tmp_path: Path) -> None:
    def reply(request: httpx.Request) -> httpx.Response:
        raise httpx.ReadTimeout("offline timeout")

    result = api().run_study(
        tmp_path / "exceptions",
        api().identity_manifest(),
        transport=httpx.MockTransport(reply),
        now=lambda: NOW,
        sleep=lambda _: None,
    )
    assert result["status"] == "COMPLETE" and result["requests"] == 5
    assert (
        json.loads((tmp_path / "exceptions/000-submissions/RESULT.json").read_text())[
            "exception_type"
        ]
        == "ReadTimeout"
    )


def companyfacts(cik: int) -> bytes:
    gaap = {}
    specs = [
        ("Revenues", "USD", 1000, False),
        ("NetIncomeLoss", "USD", 100, False),
        ("EarningsPerShareDiluted", "USD/shares", 10, False),
        ("WeightedAverageNumberOfDilutedSharesOutstanding", "shares", 10, False),
        ("NetCashProvidedByUsedInOperatingActivities", "USD", 150, False),
        ("PaymentsToAcquirePropertyPlantAndEquipment", "USD", 20, False),
        ("GrossProfit", "USD", 400, False),
        ("Assets", "USD", 2000, True),
        ("AssetsCurrent", "USD", 500, True),
        ("LiabilitiesCurrent", "USD", 200, True),
        ("LongTermDebt", "USD", 200, True),
        ("RetainedEarningsAccumulatedDeficit", "USD", 100, True),
        ("StockholdersEquity", "USD", 1500, True),
    ]
    for tag, unit, val, instant in specs:
        values = []
        for year, accession, start, end in [
            (2024, "0009999999-24-000001", "2023-10-01", "2024-09-28"),
            (2025, ACC, "2024-09-29", "2025-09-27"),
        ]:
            r = {
                "fy": year,
                "fp": "FY",
                "form": "10-K",
                "filed": f"{year}-10-31",
                "accn": accession,
                "end": end,
                "val": val,
            }
            if not instant:
                r["start"] = start
            values.append(r)
        gaap[tag] = {"units": {unit: values}}
    return json.dumps(
        {"cik": cik, "entityName": "Issuer", "facts": {"us-gaap": gaap}}
    ).encode()


def test_full_five_issuer_twenty_get_success_finishes_and_seals_before_filings(
    tmp_path: Path,
) -> None:
    calls = []
    root = tmp_path / "complete"
    roster = json.loads((REPO / "docs/evidence/ADR-422/roster.json").read_bytes())[
        "roster"
    ]
    symbols = {item["cik"]: item["symbol"] for item in roster}

    def reply(request: httpx.Request) -> httpx.Response:
        url = str(request.url)
        calls.append(url)
        if "/submissions/" in url:
            cik = int(url.rsplit("CIK", 1)[1].split(".")[0])
            body = submissions(cik)
        elif "/companyfacts/" in url:
            cik = int(url.rsplit("CIK", 1)[1].split(".")[0])
            body = companyfacts(cik)
        else:
            cik = int(request.url.path.split("/")[4])
            assert (root / f"issuer-{symbols[cik]}" / "SELECTED.json").exists()
            accession = url.rsplit("/", 1)[1][:-4]
            body = (
                filing(cik, accession, year=2024, start="2023-10-01", end="2024-09-28")
                if "-24-" in accession
                else filing(cik, accession)
            )
        return httpx.Response(200, content=body)

    result = api().run_study(
        root,
        api().identity_manifest(),
        transport=httpx.MockTransport(reply),
        now=lambda: NOW,
        sleep=lambda _: None,
    )
    assert len(calls) == 20
    assert result["status"] == "COMPLETE" and result["coverage"] == "PASS"
    assert len(result["issuers"]) == 5
    assert all(x["status"] == "PASS" for x in result["issuers"])
    assert all(
        x["record"]["combined_score"] is None and x["record"]["value_score"] is None
        for x in result["issuers"]
    )
    assert all(
        "cogs" in x["year_wrappers"][0]["missing_fields"]
        and not any(x["missing_outputs"].values())
        for x in result["issuers"]
    )
    assert result["not_requested"] == result["started_without_terminal"] == []


def test_unexpected_programming_error_is_invalid_method_and_stops_requests(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    calls = []

    def broken(*args: Any, **kwargs: Any) -> Any:
        raise RuntimeError("programming fault")

    monkeypatch.setattr(api(), "select_filings", broken)

    def reply(request: httpx.Request) -> httpx.Response:
        calls.append(str(request.url))
        return httpx.Response(200, content=submissions(51143))

    result = api().run_study(
        tmp_path / "invalid",
        api().identity_manifest(),
        transport=httpx.MockTransport(reply),
        now=lambda: NOW,
        sleep=lambda _: None,
    )
    assert len(calls) == 1 and result["status"] == "UNEVALUABLE"
    assert result["issue"]["classification"] == "INVALID_METHOD"
    assert result["coverage"] == "NOT_MEASURED" and result[
        "started_without_terminal"
    ] == ["IBM"]


def test_production_surface_requires_preacquisition_before_root(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    method = api()
    root = tmp_path / "never-create"
    monkeypatch.setattr(method, "ROOT", root)
    monkeypatch.setattr(method, "PREACQUISITION", tmp_path / "missing-pre.json")

    def no_fetch(*args: Any, **kwargs: Any) -> Any:
        raise AssertionError("no network in tests")

    monkeypatch.setattr(method.Collector, "fetch", no_fetch)
    with pytest.raises(ValueError, match="pre-acquisition"):
        method.run_study(
            root, method.identity_manifest(), now=lambda: NOW, sleep=lambda _: None
        )
    assert not root.exists()


def test_partial_http_read_failure_keeps_observed_bytes(tmp_path: Path) -> None:
    class Partial(httpx.SyncByteStream):
        def __iter__(self) -> Any:
            yield b"part"
            raise httpx.ReadError("offline broken stream")

    def reply(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, stream=Partial())

    result = api().run_study(
        tmp_path / "partial",
        api().identity_manifest(),
        transport=httpx.MockTransport(reply),
        now=lambda: NOW,
        sleep=lambda _: None,
    )
    receipt = json.loads((tmp_path / "partial/000-submissions/RESULT.json").read_text())
    assert result["requests"] == 5 and receipt["partial_body"]
    assert receipt["observed_decoded_bytes"] == receipt["retained_raw_bytes"] == 4
    assert (tmp_path / "partial/000-submissions/response.raw").read_bytes() == b"part"


def test_redirect_does_not_follow_location(tmp_path: Path) -> None:
    calls = []

    def reply(request: httpx.Request) -> httpx.Response:
        calls.append(str(request.url))
        return httpx.Response(
            302, headers={"Location": "https://forbidden.invalid"}, content=b"redirect"
        )

    result = api().run_study(
        tmp_path / "redirect",
        api().identity_manifest(),
        transport=httpx.MockTransport(reply),
        now=lambda: NOW,
        sleep=lambda _: None,
    )
    assert len(calls) == 5 and all("forbidden" not in url for url in calls)
    assert result["status"] == "COMPLETE" and result["coverage"] == "FAIL"


@pytest.mark.parametrize(
    "concept,display",
    [
        ("DocumentAnnualReport", "☒"),
        ("DocumentAnnualReport", "☑"),
        ("DocumentTransitionReport", "☐"),
    ],
)
def test_supported_ballotbox_literals(concept: str, display: str) -> None:
    raw = filing(facts={concept: display}).replace(
        f'name="dei:{concept}"'.encode(),
        f'name="dei:{concept}" format="sec:boolballotbox"'.encode(),
    )
    assert extract(raw)["anchor"].transition is False


@pytest.mark.parametrize(
    "namespace,local,display",
    [
        ("2011-07-31", "datemonthdayyearen", "September 27, 2025"),
        ("2015-02-26", "datedaymonthyearen", "27 September 2025"),
        ("2020-02-12", "date-monthname-day-year-en", "September 27, 2025"),
        ("2022-02-16", "date-day-monthname-year-en", "27 September 2025"),
    ],
)
def test_supported_exact_date_transform_pairs(
    namespace: str, local: str, display: str
) -> None:
    raw = filing(facts={"DocumentPeriodEndDate": display})
    raw = raw.replace(
        b"<html ",
        f'<html xmlns:date="http://www.xbrl.org/inlineXBRL/transformation/{namespace}" '.encode(),
    )
    raw = raw.replace(
        b'name="dei:DocumentPeriodEndDate"',
        f'name="dei:DocumentPeriodEndDate" format="date:{local}"'.encode(),
    )
    assert extract(raw)["anchor"].report_end.isoformat() == "2025-09-27"


def test_two_year_assembly_refuses_gap_before_scoring() -> None:
    older = extract(
        filing(
            accession="0009999999-24-000001",
            year=2024,
            start="2023-10-01",
            end="2024-09-28",
        ),
        selected=selected("0009999999-24-000001", "2024-09-28"),
    )
    newer = extract(filing(start="2024-09-30"))
    raw = companyfacts(123)
    observation = api().SourceObservation(
        url="company", sha256=api().sha(raw), observed_at=NOW
    )
    with pytest.raises(api().StudyFailure, match="contiguous"):
        api().assemble(
            raw=raw,
            observation=observation,
            extractions=[older, newer],
            symbol="TEST",
            as_of=NOW,
        )


def test_month_transform_is_independent_of_ambient_locale(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    import calendar

    monkeypatch.setattr(calendar, "month_name", [""] + ["not-English"] * 12)
    monkeypatch.setattr(calendar, "month_abbr", [""] + ["not-English"] * 12)
    raw = filing(facts={"DocumentPeriodEndDate": "September 27, 2025"}).replace(
        b"<html ",
        b'<html xmlns:date="http://www.xbrl.org/inlineXBRL/transformation/2022-02-16" ',
    )
    raw = raw.replace(
        b'name="dei:DocumentPeriodEndDate"',
        b'name="dei:DocumentPeriodEndDate" format="date:date-monthname-day-year-en"',
    )
    assert extract(raw)["anchor"].report_end.isoformat() == "2025-09-27"


@pytest.mark.parametrize(
    "namespace",
    [
        "http://xbrl.sec.gov/dei/not-an-official-namespace",
        "http://xbrl.sec.gov/dei/2025/evil",
        "http://xbrl.sec.gov/dei/2025-99-99",
    ],
)
def test_fake_dei_namespace_is_unsupported(namespace: str) -> None:
    raw = filing().replace(b"http://xbrl.sec.gov/dei/2025", namespace.encode())
    with pytest.raises(api().StudyFailure):
        extract(raw)


@pytest.mark.parametrize(
    "old,new",
    [
        ("<xbrli:period>", "<xbrli:period><xbrli:forever/>"),
        (
            "<xbrli:entity><xbrli:identifier",
            "<xbrli:entity><xbrli:wrong><xbrli:identifier",
        ),
        (
            "</xbrli:identifier></xbrli:entity>",
            "</xbrli:identifier></xbrli:wrong></xbrli:entity>",
        ),
        (
            "<xbrli:period><xbrli:startDate>",
            "<xbrli:period><xbrli:wrong><xbrli:startDate>",
        ),
        (
            "</xbrli:endDate></xbrli:period>",
            "</xbrli:endDate></xbrli:wrong></xbrli:period>",
        ),
    ],
)
def test_context_schema_geometry_is_direct_not_descendant(old: str, new: str) -> None:
    raw = filing()
    if "entity><xbrli:identifier" in old:
        raw = raw.replace(old.encode(), new.encode()).replace(
            b"</xbrli:identifier></xbrli:entity>",
            b"</xbrli:identifier></xbrli:wrong></xbrli:entity>",
        )
    elif "identifier></xbrli:entity" in old:
        raw = raw.replace(old.encode(), new.encode()).replace(
            b"<xbrli:entity><xbrli:identifier",
            b"<xbrli:entity><xbrli:wrong><xbrli:identifier",
        )
    elif "period><xbrli:startDate" in old:
        raw = raw.replace(old.encode(), new.encode()).replace(
            b"</xbrli:endDate></xbrli:period>",
            b"</xbrli:endDate></xbrli:wrong></xbrli:period>",
        )
    elif "endDate></xbrli:period" in old:
        raw = raw.replace(old.encode(), new.encode()).replace(
            b"<xbrli:period><xbrli:startDate>",
            b"<xbrli:period><xbrli:wrong><xbrli:startDate>",
        )
    else:
        raw = raw.replace(old.encode(), new.encode())
    with pytest.raises(api().StudyFailure):
        extract(raw)


def test_unrelated_binary_exhibit_does_not_invalidate_supported_primary() -> None:
    raw = (
        filing()
        + b"\n<DOCUMENT><TYPE>GRAPHIC\n<FILENAME>image.bin\n<TEXT>\xff\xfe\x00</TEXT></DOCUMENT>"
    )
    assert extract(raw)["anchor"].fiscal_year == 2025


def test_unrelated_legacy_parse_refusal_is_diagnostic_not_anchor_coverage_failure() -> (
    None
):
    raw = json.loads(companyfacts(123))
    rows = raw["facts"]["us-gaap"]["Revenues"]["units"]["USD"]
    rows.append(
        {
            "fy": 2030,
            "fp": "FY",
            "form": "10-K",
            "filed": "2030-10-31",
            "accn": "0009999999-30-000001",
            "start": "bad",
            "end": "bad",
            "val": 10,
        }
    )
    body = json.dumps(raw).encode()
    older = extract(
        filing(
            accession="0009999999-24-000001",
            year=2024,
            start="2023-10-01",
            end="2024-09-28",
        ),
        selected=selected("0009999999-24-000001", "2024-09-28"),
    )
    newer = extract()
    observation = api().SourceObservation(
        url="company", sha256=api().sha(body), observed_at=NOW
    )
    result = api().assemble(
        raw=body,
        observation=observation,
        extractions=[older, newer],
        symbol="TEST",
        as_of=NOW,
    )
    assert (
        result["status"] == "PASS"
        and result["legacy_comparison"]["status"] == "REFUSED"
    )
    assert "reason" in result["legacy_comparison"] and result["legacy_years"] is None


def test_disk_write_error_is_invalid_method_not_transport_failure(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    original = Path.open

    def failing_open(path: Path, *args: Any, **kwargs: Any) -> Any:
        if path.name == "response.raw":
            raise OSError("synthetic disk fault")
        return original(path, *args, **kwargs)

    monkeypatch.setattr(Path, "open", failing_open)
    result = api().run_study(
        tmp_path / "disk",
        api().identity_manifest(),
        transport=httpx.MockTransport(lambda _: httpx.Response(200, content=b"x")),
        now=lambda: NOW,
        sleep=lambda _: None,
    )
    assert (
        result["status"] == "UNEVALUABLE"
        and result["issue"]["classification"] == "INVALID_METHOD"
    )
    assert result["requests"] == 1 and result["coverage"] == "NOT_MEASURED"


def test_production_preacquisition_requires_frozen_review_receipts(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    method = api()
    root = tmp_path / "live-surface"
    pre = tmp_path / "PREACQUISITION.json"
    monkeypatch.setattr(method, "ROOT", root)
    monkeypatch.setattr(method, "PREACQUISITION", pre)
    payload = {
        "identity": method.identity_manifest(),
        "research_review": "APPROVE",
        "data_review": "APPROVE",
    }
    pre.write_text(json.dumps(payload))

    def no_fetch(*args: Any, **kwargs: Any) -> Any:
        raise AssertionError("no network in test")

    monkeypatch.setattr(method.Collector, "fetch", no_fetch)
    with pytest.raises(ValueError, match="receipt"):
        method.run_study(root, method.identity_manifest(), now=lambda: NOW)
    assert not root.exists()


def test_production_preacquisition_copies_and_binds_reviews_before_fetch(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    method = api()
    root = tmp_path / "live-surface"
    pre = tmp_path / "PREACQUISITION.json"
    monkeypatch.setattr(method, "ROOT", root)
    monkeypatch.setattr(method, "PREACQUISITION", pre)
    receipts = {}
    for role in ("research_review", "data_review", "focused_test"):
        path = tmp_path / f"{role}.txt"
        path.write_bytes(role.encode())
        receipts[role] = {"path": str(path), "sha256": method.sha(path.read_bytes())}
    payload = {
        "identity": method.identity_manifest(),
        "research_review": "APPROVE",
        "data_review": "APPROVE",
        "receipts": receipts,
    }
    pre.write_text(json.dumps(payload))

    def no_fetch(*args: Any, **kwargs: Any) -> Any:
        start = json.loads((root / "START.json").read_bytes())
        assert start["preacquisition_sha256"] == method.sha(pre.read_bytes())
        assert (root / "PREACQUISITION.json").read_bytes() == pre.read_bytes()
        retained = list((root / "preacquisition-receipts").glob("*"))
        assert len(retained) == 3 and {p.read_bytes() for p in retained} == {
            x.encode() for x in receipts
        }
        raise method.BudgetStop("offline stops before HTTP")

    monkeypatch.setattr(method.Collector, "fetch", no_fetch)
    result = method.run_study(root, method.identity_manifest(), now=lambda: NOW)
    assert result["status"] == "INCOMPLETE" and result["requests"] == 0


def test_overall_elapsed_ceiling_before_stage_makes_no_request(tmp_path: Path) -> None:
    times = iter([0.0, 600.0, 600.0, 600.0])
    result = api().run_study(
        tmp_path / "elapsed",
        api().identity_manifest(),
        transport=httpx.MockTransport(lambda _: pytest.fail("request after deadline")),
        clock=lambda: next(times),
        now=lambda: NOW,
        sleep=lambda _: None,
    )
    assert result["status"] == "INCOMPLETE" and result["requests"] == 0
    assert len(result["not_requested"]) == 5


def test_clock_exhaustion_after_parse_stops_before_filing_request(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    method = api()
    clock_value = [0.0]
    original = method.select_filings

    def select(*args: Any, **kwargs: Any) -> Any:
        result = original(*args, **kwargs)
        clock_value[0] = 700.0
        return result

    monkeypatch.setattr(method, "select_filings", select)
    result = method.run_study(
        tmp_path / "parse-deadline",
        method.identity_manifest(),
        transport=httpx.MockTransport(
            lambda _: httpx.Response(200, content=submissions(51143))
        ),
        clock=lambda: clock_value[0],
        now=lambda: NOW,
        sleep=lambda _: None,
    )
    assert result["status"] == "INCOMPLETE" and result["requests"] == 1
    assert not (tmp_path / "parse-deadline/issuer-IBM/SELECTED.json").exists()


@given(st.integers(-30, 30).filter(lambda gap: gap != 0))
def test_noncontiguous_geometry_never_reaches_quality_score(gap: int) -> None:
    from datetime import date, timedelta

    older = extract(
        filing(
            accession="0009999999-24-000001",
            year=2024,
            start="2023-10-01",
            end="2024-09-28",
        ),
        selected=selected("0009999999-24-000001", "2024-09-28"),
    )
    start = (date(2024, 9, 29) + timedelta(days=gap)).isoformat()
    newer = extract(filing(start=start))
    raw = companyfacts(123)
    observation = api().SourceObservation(
        url="cf", sha256=api().sha(raw), observed_at=NOW
    )
    with pytest.raises(api().StudyFailure, match="contiguous"):
        api().assemble(
            raw=raw,
            observation=observation,
            extractions=[older, newer],
            symbol="TEST",
            as_of=NOW,
        )


def test_failed_anchor_still_retains_complete_primary_header_and_portability_verdict(
    tmp_path: Path,
) -> None:
    root = tmp_path / "unsupported"

    def reply(request: httpx.Request) -> httpx.Response:
        url = str(request.url)
        if "/submissions/" in url:
            cik = int(url.rsplit("CIK", 1)[1].split(".")[0])
            body = submissions(cik)
        else:
            cik = int(request.url.path.split("/")[4])
            accession = url.rsplit("/", 1)[1][:-4]
            body = filing(
                cik,
                accession,
                year=2024,
                start="2023-10-01",
                end="2024-09-28",
                facts={"DocumentTransitionReport": "true"},
            )
        return httpx.Response(200, content=body)

    result = api().run_study(
        root,
        api().identity_manifest(),
        transport=httpx.MockTransport(reply),
        now=lambda: NOW,
        sleep=lambda _: None,
    )
    assert (
        result["status"] == "COMPLETE"
        and result["coverage"] == "FAIL"
        and result["requests"] == 10
    )
    assert result["portable_completeness"] == "COMPLETE_DECLARED_COMPONENTS"
    primary = gzip.decompress((root / "issuer-IBM/anchor-0-primary.gz").read_bytes())
    header = gzip.decompress((root / "issuer-IBM/anchor-0-header.gz").read_bytes())
    assert primary.startswith(b"<DOCUMENT>") and header.startswith(b"<SEC-HEADER>")
    assert b"DocumentTransitionReport" in primary
    assert any(
        item.get("publication_kind") == "ROOT_ONLY_COMPLETE_SUBMISSION"
        for item in result["packaging"]
    )
