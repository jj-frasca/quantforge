"""ADR422 single-attempt quality source coverage. Imports and offline tests do no I/O.

Only main(--live) can create the registered root or use the production transport.
Original-anchor support is intentionally restricted; no recovery or fallback.
"""

from __future__ import annotations

import argparse
import ast
import gzip
import hashlib
import json
import os
import re
import subprocess
import sys
import time
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, date, datetime, timedelta
from pathlib import Path
from typing import Any

import httpx
import lxml  # type: ignore[import-untyped]
from lxml import etree

from app.data.anchored_fundamentals import (
    FilingAnnualAnchor,
    SourceObservation,
    evaluate_anchored_fundamentals,
)
from app.data.fundamentals import FundamentalsHistory, parse_company_facts_history
from app.research.fundamentals.record import compute_fundamental_record

REPO = Path("/Users/joefrasca/claude-work/quantforge-codex")
HERE = Path(__file__).resolve().parent
ROOT = Path("/tmp/qf-w45-s7-two-year-quality-coverage")
PROTOCOL = REPO / "docs/adr/ADR-422-measure-two-year-quality-input-coverage.md"
ROSTER = REPO / "docs/evidence/ADR-422/roster.json"
PREACQUISITION = HERE / "PREACQUISITION.json"
DEADLINE = datetime(2026, 11, 7, 11, tzinfo=UTC)
X = "http://www.xbrl.org/2003/instance"
IX = {"http://www.xbrl.org/2013/inlineXBRL", "http://www.xbrl.org/2008/inlineXBRL"}
DEI = (
    "DocumentType",
    "DocumentFiscalPeriodFocus",
    "DocumentFiscalYearFocus",
    "DocumentPeriodEndDate",
    "DocumentAnnualReport",
    "DocumentTransitionReport",
)
DATE_FORMATS = {
    (f"http://www.xbrl.org/inlineXBRL/transformation/{version}", local): order
    for version, old in [
        ("2011-07-31", True),
        ("2015-02-26", True),
        ("2020-02-12", False),
        ("2022-02-16", False),
    ]
    for local, order in (
        [("datemonthdayyearen", "mdy"), ("datedaymonthyearen", "dmy")]
        if old
        else [
            ("date-monthname-day-year-en", "mdy"),
            ("date-day-monthname-year-en", "dmy"),
        ]
    )
}
BOOL_FORMATS = {
    (f"{scheme}://www.sec.gov/inlineXBRL/transformation/2015-08-31", "boolballotbox")
    for scheme in ("http", "https")
}
REQUIRED_OUTPUTS = (
    "revenue",
    "net_income",
    "eps",
    "shares_diluted",
    "free_cash_flow",
    "total_assets",
    "total_current_assets",
    "total_current_liabilities",
    "long_term_debt",
    "gross_profit",
    "operating_cash_flow",
    "retained_earnings",
    "total_equity",
)


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def encode(value: Any) -> bytes:
    return (
        json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False)
        + "\n"
    ).encode()


def durable(path: Path, raw: bytes) -> None:
    with path.open("xb") as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())


def utc_now() -> datetime:
    return datetime.now(UTC)


def user_agent() -> str:
    tree = ast.parse((REPO / "backend/scripts/fundamental_sweep.py").read_text())
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(
            isinstance(target, ast.Name) and target.id == "USER_AGENT"
            for target in node.targets
        ):
            value = ast.literal_eval(node.value)
            if isinstance(value, str):
                return value
    raise ValueError("published USER_AGENT constant unavailable")


def identity_manifest() -> dict[str, Any]:
    files = {
        "protocol_sha256": PROTOCOL,
        "roster_sha256": ROSTER,
        "code_sha256": Path(__file__),
        "tests_sha256": HERE / "test_coverage422.py",
        "lock_sha256": REPO / "backend/uv.lock",
        "app421_sha256": REPO / "backend/app/data/anchored_fundamentals.py",
        "fundamentals_sha256": REPO / "backend/app/data/fundamentals.py",
        "record_sha256": REPO / "backend/app/research/fundamentals/record.py",
        "quality_sha256": REPO / "backend/app/research/fundamentals/quality.py",
        "flow_facts_sha256": REPO / "backend/app/data/flow_facts.py",
        "json_value_sha256": REPO / "backend/app/data/models/json_value.py",
        "valuation_score_sha256": REPO / "backend/app/research/valuation/score.py",
        "httpx_module_sha256": Path(httpx.__file__),
        "lxml_module_sha256": Path(lxml.__file__),
        "lxml_etree_sha256": Path(etree.__file__),
    }
    result: dict[str, Any] = {
        key: sha(path.read_bytes()) for key, path in files.items()
    }
    result.update(
        {
            "schema": "adr422-identity-v1",
            "httpx_version": httpx.__version__,
            "lxml_version": lxml.__version__,
            "python_version": sys.version,
            "user_agent": user_agent(),
            "roster_revision": json.loads(ROSTER.read_bytes())["revision"],
            "executed_git_revision": subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=REPO, text=True
            ).strip(),
            "libxml_version": list(etree.LIBXML_VERSION),
            "libxslt_version": list(etree.LIBXSLT_VERSION),
        }
    )
    return result


class StudyFailure(Exception):
    def __init__(
        self, category: str, reason: str, evidence: dict[str, Any] | None = None
    ) -> None:
        super().__init__(reason)
        self.category = category
        self.evidence = evidence or {}
        self.components: dict[str, bytes] = {}


class BudgetStop(Exception):
    pass


@dataclass(frozen=True)
class Limits:
    body_bytes: int = 64 * 1024 * 1024
    total_bytes: int = 256 * 1024 * 1024
    study_seconds: float = 600.0
    request_seconds: float = 60.0

    def validate(self) -> None:
        if not (
            0 < self.body_bytes <= 64 * 1024 * 1024
            and 0 < self.total_bytes <= 256 * 1024 * 1024
            and 0 < self.study_seconds <= 600
            and 0 < self.request_seconds <= 60
        ):
            raise ValueError("test limits may only narrow frozen limits")


def _json(raw: bytes) -> dict[str, Any]:
    try:
        value = json.loads(raw)
    except (ValueError, UnicodeDecodeError) as exc:
        raise StudyFailure("SOURCE_SELECTION_FAILURE", "invalid source JSON") from exc
    if not isinstance(value, dict):
        raise StudyFailure("SOURCE_SELECTION_FAILURE", "source JSON is not an object")
    return value


def select_filings(raw: bytes, cik: int) -> list[dict[str, str]]:
    data = _json(raw)
    identity = data.get("cik")
    if (
        type(identity) not in (str, int)
        or not str(identity).isdigit()
        or int(str(identity)) != cik
    ):
        raise StudyFailure("IDENTITY_FAILURE", "submissions issuer mismatch")
    filings = data.get("filings")
    recent = filings.get("recent") if isinstance(filings, dict) else None
    keys = ("accessionNumber", "form", "filingDate", "reportDate")
    if not isinstance(recent, dict) or any(
        not isinstance(recent.get(key), list) for key in keys
    ):
        raise StudyFailure("SOURCE_SELECTION_FAILURE", "missing submissions arrays")
    lengths = {len(recent[key]) for key in keys}
    if len(lengths) != 1:
        raise StudyFailure(
            "SOURCE_SELECTION_FAILURE", "submissions array lengths disagree"
        )
    rows = []
    seen = set()
    for values in zip(*(recent[key] for key in keys), strict=True):
        if any(type(value) is not str for value in values):
            raise StudyFailure(
                "SOURCE_SELECTION_FAILURE", "nonstring submissions label"
            )
        row = dict(zip(keys, values, strict=True))
        accession = row["accessionNumber"]
        if not re.fullmatch(r"\d{10}-\d{2}-\d{6}", accession) or accession in seen:
            raise StudyFailure(
                "SOURCE_SELECTION_FAILURE", "invalid/duplicate accession"
            )
        seen.add(accession)
        if row["form"] == "10-K":
            for key in ("filingDate", "reportDate"):
                try:
                    date.fromisoformat(row[key])
                except ValueError as exc:
                    raise StudyFailure(
                        "SOURCE_SELECTION_FAILURE", "invalid exact-10-K date"
                    ) from exc
                if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", row[key]):
                    raise StudyFailure("SOURCE_SELECTION_FAILURE", "noncanonical date")
            rows.append(row)
    rows.sort(key=lambda row: (row["filingDate"], row["accessionNumber"]), reverse=True)
    if len(rows) < 2:
        raise StudyFailure(
            "SOURCE_SELECTION_FAILURE", "fewer than two exact-10-K candidates"
        )
    return list(reversed(rows[:2]))


def _local(tag: str) -> tuple[str, str]:
    if tag.startswith("{"):
        return tuple(tag[1:].split("}", 1))  # type: ignore[return-value]
    return "", tag


def _qname(node: Any, value: str) -> tuple[str, str]:
    if ":" in value:
        prefix, name = value.split(":", 1)
        namespace = node.nsmap.get(prefix)
    else:
        name = value
        namespace = node.nsmap.get(None)
    if namespace is None:
        raise StudyFailure("UNSUPPORTED_ANCHOR", "unresolved QName")
    return namespace, name


def _literal(node: Any, concept: str) -> Any:
    if (
        any(_local(str(key))[1] == "nil" for key in node.attrib)
        or node.get("continuedAt") is not None
    ):
        raise StudyFailure("UNSUPPORTED_ANCHOR", "nil or continuation DEI")
    if any(
        _local(str(child.tag))[0] in IX and _local(str(child.tag))[1] == "exclude"
        for child in node.iter()
    ):
        raise StudyFailure("UNSUPPORTED_ANCHOR", "inline exclude DEI")
    value = "".join(node.itertext()).strip()
    fmt = node.get("format")
    qualified = _qname(node, fmt) if fmt else None
    if concept in ("DocumentAnnualReport", "DocumentTransitionReport"):
        if qualified is None and value in ("true", "false", "1", "0"):
            return value in ("true", "1")
        if qualified in BOOL_FORMATS and value in ("☐", "☑", "☒"):
            return value != "☐"
        raise StudyFailure(
            "UNSUPPORTED_ANCHOR", "unsupported boolean transform or literal"
        )
    if concept == "DocumentPeriodEndDate":
        if qualified is None and re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
            try:
                return date.fromisoformat(value).isoformat()
            except ValueError as exc:
                raise StudyFailure(
                    "UNSUPPORTED_ANCHOR", "invalid ISO DEI date"
                ) from exc
        if qualified not in DATE_FORMATS:
            raise StudyFailure("UNSUPPORTED_ANCHOR", "unsupported date transform")
        english_months = (
            "january",
            "february",
            "march",
            "april",
            "may",
            "june",
            "july",
            "august",
            "september",
            "october",
            "november",
            "december",
        )
        month_names = {name: index for index, name in enumerate(english_months, 1)}
        month_names.update(
            {name[:3]: index for index, name in enumerate(english_months, 1)}
        )
        pattern = (
            r"([A-Za-z]+)\s+(\d{1,2}),?\s+(\d{4})"
            if DATE_FORMATS[qualified] == "mdy"
            else r"(\d{1,2})\s+([A-Za-z]+),?\s+(\d{4})"
        )
        match = re.fullmatch(pattern, value)
        if match is None:
            raise StudyFailure("UNSUPPORTED_ANCHOR", "unsupported month-name DEI date")
        month, day = (
            (match[1], match[2])
            if DATE_FORMATS[qualified] == "mdy"
            else (match[2], match[1])
        )
        try:
            return date(int(match[3]), month_names[month.lower()], int(day)).isoformat()
        except (ValueError, KeyError) as exc:
            raise StudyFailure(
                "UNSUPPORTED_ANCHOR", "invalid month-name DEI date"
            ) from exc
    if qualified is not None:
        raise StudyFailure("UNSUPPORTED_ANCHOR", "unexpected DEI transform")
    return value


def extract_anchor(
    *, raw: bytes, cik: int, selected: dict[str, str], observed_at: datetime, url: str
) -> dict[str, Any]:
    audit: dict[str, Any] = {
        "source_sha256": sha(raw),
        "inventory": [],
        "header": {},
        "contexts": {},
        "dei": [],
        "status": "UNSUPPORTED",
    }
    components: dict[str, bytes] = {}
    try:
        raw_headers = re.findall(
            rb"<SEC-HEADER>(.*?)</SEC-HEADER>", raw, re.DOTALL | re.IGNORECASE
        )
        if len(raw_headers) != 1:
            raise StudyFailure("UNSUPPORTED_ANCHOR", "missing/ambiguous SEC header")
        try:
            header = raw_headers[0].decode("utf-8")
        except UnicodeDecodeError as exc:
            raise StudyFailure("UNSUPPORTED_ANCHOR", "non-UTF8 SEC header") from exc
        labels: dict[str, Any] = {"raw": header}
        for key, label in [
            ("accession", "ACCESSION NUMBER"),
            ("cik", "CENTRAL INDEX KEY"),
            ("form", "CONFORMED SUBMISSION TYPE"),
            ("report_end", "CONFORMED PERIOD OF REPORT"),
            ("filed", "FILED AS OF DATE"),
            ("changed", "DATE AS OF CHANGE"),
        ]:
            labels[key] = re.findall(
                r"^\s*" + re.escape(label) + r":\s*([^\r\n]+)", header, re.MULTILINE
            )
        labels["acceptance_raw"] = re.findall(
            r"<ACCEPTANCE-DATETIME>\s*([^\r\n<]+)", header, re.IGNORECASE
        )
        audit["header"] = labels
        for key, want in [
            ("accession", selected["accessionNumber"]),
            ("cik", str(cik)),
            ("form", "10-K"),
            ("report_end", selected["reportDate"].replace("-", "")),
        ]:
            header_values = labels[key]
            if key == "cik":
                header_values = [
                    str(int(value)) if value.isdigit() else value
                    for value in header_values
                ]
            if not header_values or set(header_values) != {want}:
                raise StudyFailure("IDENTITY_FAILURE", "header mismatch " + key)
        blocks = list(
            re.finditer(rb"<DOCUMENT>(.*?)</DOCUMENT>", raw, re.DOTALL | re.IGNORECASE)
        )
        if len(blocks) != len(re.findall(rb"<DOCUMENT>", raw, re.IGNORECASE)):
            raise StudyFailure("UNSUPPORTED_ANCHOR", "unbalanced SGML documents")
        primaries = []
        for index, match in enumerate(blocks):
            block = match.group(1)
            types = re.findall(rb"<TYPE>\s*([^\r\n<]+)", block, re.IGNORECASE)
            filenames = re.findall(rb"<FILENAME>\s*([^\r\n<]+)", block, re.IGNORECASE)
            bodies = re.findall(
                rb"<TEXT>\s*(.*?)\s*</TEXT>", block, re.DOTALL | re.IGNORECASE
            )
            entry = {
                "index": index,
                "type": types[0].decode().strip() if len(types) == 1 else None,
                "filename": filenames[0].decode().strip()
                if len(filenames) == 1
                else None,
                "block_sha256": sha(match.group(0)),
                "block_bytes": len(match.group(0)),
                "body_sha256": sha(bodies[0]) if len(bodies) == 1 else None,
            }
            audit["inventory"].append(entry)
            if entry["type"] == "10-K":
                primaries.append((match.group(0), bodies))
        if len(primaries) != 1 or len(primaries[0][1]) != 1:
            raise StudyFailure("UNSUPPORTED_ANCHOR", "no unique complete primary10-K")
        primary, bodies = primaries[0]
        full_header = re.search(
            rb"<SEC-HEADER>.*?</SEC-HEADER>", raw, re.DOTALL | re.IGNORECASE
        )
        assert full_header is not None
        components = {"primary": primary, "header": full_header.group(0)}
        body = bodies[0]
        if re.search(rb"<!DOCTYPE|<!ENTITY", body, re.IGNORECASE):
            raise StudyFailure("UNSUPPORTED_ANCHOR", "DOCTYPE/entity unsupported")
        wrapper = re.fullmatch(rb"<XBRL>\s*(.*?)\s*</XBRL>", body.strip(), re.DOTALL)
        parse_body = wrapper.group(1) if wrapper else body
        audit["sgml_xbrl_wrapper"] = bool(wrapper)
        audit["parse_body_sha256"] = sha(parse_body)
        parser = etree.XMLParser(
            resolve_entities=False,
            no_network=True,
            load_dtd=False,
            recover=False,
            huge_tree=False,
        )
        try:
            tree = etree.fromstring(parse_body, parser)
        except etree.XMLSyntaxError as exc:
            raise StudyFailure(
                "UNSUPPORTED_ANCHOR", "malformed/unsupported local XHTML"
            ) from exc
        if _local(str(tree.tag)) != ("http://www.w3.org/1999/xhtml", "html"):
            raise StudyFailure("UNSUPPORTED_ANCHOR", "not inline XHTML primary")
        contexts = {}
        for node in tree.iter("{" + X + "}context"):
            identity = node.get("id")
            if not identity or identity in contexts:
                raise StudyFailure("UNSUPPORTED_ANCHOR", "missing/duplicate context ID")
            contexts[identity] = node
            audit["contexts"][identity] = {
                "xml": etree.tostring(node, encoding="unicode")
            }
        intervals = []
        values: dict[str, list[Any]] = {key: [] for key in DEI}
        for node in tree.iter():
            namespace, local = _local(str(node.tag))
            if namespace not in IX or local not in (
                "nonNumeric",
                "nonFraction",
                "fraction",
            ):
                continue
            concept_namespace, concept = _qname(node, node.get("name", ""))
            if concept not in DEI:
                continue
            dei_match = re.fullmatch(
                r"http://xbrl\.sec\.gov/dei/(\d{4}(?:-\d{2}-\d{2})?)", concept_namespace
            )
            if dei_match is None or local != "nonNumeric":
                raise StudyFailure(
                    "UNSUPPORTED_ANCHOR", "unsupported DEI namespace/representation"
                )
            try:
                date.fromisoformat(
                    dei_match[1] if len(dei_match[1]) == 10 else dei_match[1] + "-01-01"
                )
            except ValueError as exc:
                raise StudyFailure(
                    "UNSUPPORTED_ANCHOR", "invalid DEI taxonomy date"
                ) from exc
            context = contexts.get(node.get("contextRef"))
            if context is None:
                raise StudyFailure("UNSUPPORTED_ANCHOR", "unresolved DEI context")
            entities = context.findall("{" + X + "}entity")
            periods = context.findall("{" + X + "}period")
            if len(entities) != 1 or len(periods) != 1 or len(context) != 2:
                raise StudyFailure(
                    "UNSUPPORTED_ANCHOR", "context needs direct entity and period"
                )
            entity, period = entities[0], periods[0]
            ids = entity.findall("{" + X + "}identifier")
            starts = period.findall("{" + X + "}startDate")
            ends = period.findall("{" + X + "}endDate")
            instants = period.findall("{" + X + "}instant")
            if (
                len(entity) != 1
                or len(period) != 2
                or any(
                    _local(str(child.tag)) not in ((X, "startDate"), (X, "endDate"))
                    for child in period
                )
            ):
                raise StudyFailure(
                    "UNSUPPORTED_ANCHOR", "unsupported direct context geometry"
                )
            if (
                len(ids) != 1
                or ids[0].get("scheme") != "http://www.sec.gov/CIK"
                or not (ids[0].text or "").isdigit()
                or int(ids[0].text) != cik
            ):
                raise StudyFailure("UNSUPPORTED_ANCHOR", "context issuer mismatch")
            if (
                len(starts) != 1
                or len(ends) != 1
                or instants
                or any(
                    _local(str(n.tag))[1]
                    in ("segment", "scenario", "explicitMember", "typedMember")
                    for n in context.iter()
                )
            ):
                raise StudyFailure(
                    "UNSUPPORTED_ANCHOR", "not a dimensionless annual duration"
                )
            interval = (starts[0].text, ends[0].text)
            if any(
                not isinstance(v, str) or re.fullmatch(r"\d{4}-\d{2}-\d{2}", v) is None
                for v in interval
            ):
                raise StudyFailure("UNSUPPORTED_ANCHOR", "noncanonical context date")
            try:
                start, end = (date.fromisoformat(v) for v in interval)
            except ValueError as exc:
                raise StudyFailure(
                    "UNSUPPORTED_ANCHOR", "invalid context date"
                ) from exc
            if start >= end or end.isoformat() != selected["reportDate"]:
                raise StudyFailure("UNSUPPORTED_ANCHOR", "context/report date mismatch")
            intervals.append(interval)
            value = _literal(node, concept)
            values[concept].append(value)
            audit["dei"].append(
                {
                    "concept": concept,
                    "namespace": concept_namespace,
                    "attributes": dict(node.attrib),
                    "namespaces": {str(k): v for k, v in node.nsmap.items()},
                    "contextRef": node.get("contextRef"),
                    "text": "".join(node.itertext()),
                    "value": value,
                    "xml": etree.tostring(node, encoding="unicode"),
                }
            )
        if any(
            not entries or any(value != entries[0] for value in entries)
            for entries in values.values()
        ):
            raise StudyFailure(
                "UNSUPPORTED_ANCHOR", "missing/conflicting six-DEI values"
            )
        if not intervals or any(interval != intervals[0] for interval in intervals):
            raise StudyFailure("UNSUPPORTED_ANCHOR", "DEI annual intervals disagree")
        normalized = {key: entries[0] for key, entries in values.items()}
        if (
            normalized["DocumentType"] != "10-K"
            or normalized["DocumentFiscalPeriodFocus"] != "FY"
            or normalized["DocumentPeriodEndDate"] != selected["reportDate"]
            or normalized["DocumentAnnualReport"] is not True
            or normalized["DocumentTransitionReport"] is not False
            or re.fullmatch(r"\d{4}", normalized["DocumentFiscalYearFocus"]) is None
        ):
            raise StudyFailure("UNSUPPORTED_ANCHOR", "six-DEI declarations unsupported")
        anchor = FilingAnnualAnchor(
            cik=cik,
            fiscal_year=int(normalized["DocumentFiscalYearFocus"]),
            accession_number=selected["accessionNumber"],
            annual_start=date.fromisoformat(intervals[0][0]),
            report_end=date.fromisoformat(intervals[0][1]),
            original=SourceObservation(
                url=url, sha256=sha(raw), observed_at=observed_at
            ),
            header_labels=labels,
        )
        audit["status"] = "SUPPORTED"
        audit["primary_sha256"] = sha(primary)
        return {
            "anchor": anchor,
            "audit": audit,
            "components": components,
        }
    except StudyFailure as exc:
        exc.evidence = audit
        exc.components = components
        raise


def assemble(
    *,
    raw: bytes,
    observation: SourceObservation,
    extractions: list[dict[str, Any]],
    symbol: str,
    as_of: datetime,
) -> dict[str, Any]:
    if len(extractions) != 2:
        raise StudyFailure("CONTINUITY_FAILURE", "requires exactly two anchors")
    anchors = [value["anchor"] for value in extractions]
    older, newer = anchors
    if (
        older.cik != newer.cik
        or older.accession_number == newer.accession_number
        or older.fiscal_year + 1 != newer.fiscal_year
        or older.report_end + timedelta(days=1) != newer.annual_start
    ):
        raise StudyFailure(
            "CONTINUITY_FAILURE",
            "annual anchors not issuer-bound, adjacent and physically contiguous",
        )
    wrappers = []
    for anchor in anchors:
        try:
            wrapper = evaluate_anchored_fundamentals(
                raw=raw,
                symbol=symbol,
                observation=observation,
                anchor=anchor,
                as_of=as_of,
            )
        except ValueError as exc:
            raise StudyFailure(
                "CONFLICT_FAILURE"
                if "conflicting eligible" in str(exc)
                else "SELECTION_FAILURE",
                str(exc),
            ) from exc
        wrappers.append(wrapper)
    history = FundamentalsHistory(
        symbol=symbol,
        cik=newer.cik,
        entity_name=wrappers[-1].history.entity_name,
        form="10-K",
        accession_number=newer.accession_number,
        source_url=newer.original.url,
        years=tuple(wrapper.history.years[0] for wrapper in wrappers),
    )
    missing = {
        str(year.fiscal_year): [
            field for field in REQUIRED_OUTPUTS if getattr(year, field) is None
        ]
        for year in history.years
    }
    try:
        legacy = parse_company_facts_history(_json(raw), symbol)
    except (ValueError, OverflowError) as exc:
        comparison_status = {
            "status": "REFUSED",
            "reason": str(exc),
            "exception_type": type(exc).__name__,
        }
        comparisons = None
    else:
        comparison_status = {"status": "MEASURED"}
        comparisons = {
            str(anchor.fiscal_year): next(
                (
                    year.model_dump(mode="json")
                    for year in legacy.years
                    if year.fiscal_year == anchor.fiscal_year
                ),
                None,
            )
            for anchor in anchors
        }
    return {
        "status": "PASS" if not any(missing.values()) else "MISSING_OUTPUTS",
        "missing_outputs": missing,
        "available_at": max(wrapper.available_at for wrapper in wrappers).isoformat(),
        "year_wrappers": [wrapper.model_dump(mode="json") for wrapper in wrappers],
        "history": history.model_dump(mode="json"),
        "record": compute_fundamental_record(history).model_dump(mode="json"),
        "legacy_years": comparisons,
        "legacy_comparison": comparison_status,
        "basis_limitation": "Matching original annual periods does not certify EPS/share corporate-action or split-basis comparability across filings; quality scores remain conditional.",
    }


class Collector:
    def __init__(
        self,
        root: Path,
        limits: Limits,
        transport: httpx.BaseTransport | None,
        clock: Callable[[], float],
        now: Callable[[], datetime],
        sleep: Callable[[float], None],
    ) -> None:
        self.root = root
        self.limits = limits
        self.transport = transport
        self.clock = clock
        self.now = now
        self.sleep = sleep
        self.started = clock()
        self.last_start: float | None = None
        self.total = 0
        self.count = 0
        self.packaging: list[dict[str, Any]] = []

    def budget(self) -> None:
        if (
            self.clock() - self.started >= self.limits.study_seconds
            or self.total >= self.limits.total_bytes
        ):
            raise BudgetStop("fixed study budget exhausted")

    def fetch(self, url: str, label: str) -> tuple[bytes, dict[str, Any]]:
        self.budget()
        if self.count >= 20:
            raise BudgetStop("fixed request count exhausted")
        if self.last_start is not None:
            self.sleep(max(0.0, 0.2 - (self.clock() - self.last_start)))
        self.budget()
        directory = self.root / f"{self.count:03d}-{label}"
        directory.mkdir()
        started = self.clock()
        self.last_start = started
        self.count += 1
        receipt: dict[str, Any] = {
            "url": url,
            "request_started_at_utc": self.now().isoformat(),
            "http_status": None,
            "final_url": None,
            "headers": {},
            "observed_decoded_bytes": 0,
            "retained_raw_bytes": 0,
            "reason": None,
            "exception_type": None,
            "exception_message": None,
            "representation": "retained HTTP-decoded response bytes",
        }
        durable(directory / "START.json", encode(receipt))
        raw_path = directory / "response.raw"
        active = (
            self.transport
            if self.transport is not None
            else httpx.HTTPTransport(retries=0, trust_env=False)
        )
        try:
            with raw_path.open("xb") as out:
                with (
                    httpx.Client(
                        transport=active,
                        trust_env=False,
                        follow_redirects=False,
                        auth=None,
                        headers={
                            "User-Agent": user_agent(),
                            "Accept-Encoding": "identity",
                        },
                        timeout=httpx.Timeout(connect=10, read=15, write=15, pool=10),
                    ) as client,
                    client.stream("GET", url) as response,
                ):
                    receipt["http_status"] = response.status_code
                    receipt["final_url"] = str(response.url)
                    receipt["headers"] = {
                        k: response.headers[k]
                        for k in (
                            "date",
                            "content-type",
                            "content-length",
                            "content-encoding",
                            "location",
                            "etag",
                            "last-modified",
                        )
                        if k in response.headers
                    }
                    for chunk in response.iter_bytes():
                        receipt["observed_decoded_bytes"] += len(chunk)
                        remaining = min(
                            self.limits.body_bytes - receipt["retained_raw_bytes"],
                            self.limits.total_bytes - self.total,
                        )
                        admitted = chunk[:remaining]
                        out.write(admitted)
                        out.flush()
                        os.fsync(out.fileno())
                        receipt["retained_raw_bytes"] += len(admitted)
                        self.total += len(admitted)
                        if (
                            receipt["retained_raw_bytes"] >= self.limits.body_bytes
                            or self.total >= self.limits.total_bytes
                        ):
                            receipt["reason"] = "body_or_cohort_limit"
                            break
                        if (
                            self.clock() - started >= self.limits.request_seconds
                            or self.clock() - self.started >= self.limits.study_seconds
                        ):
                            receipt["reason"] = "elapsed_limit"
                            break
                out.flush()
                os.fsync(out.fileno())
        except httpx.HTTPError as exc:
            receipt["reason"] = "transport_exception"
            receipt["exception_type"] = type(exc).__name__
            receipt["exception_message"] = str(exc)
        raw = raw_path.read_bytes() if raw_path.exists() else b""
        if receipt["reason"] is None:
            if (
                self.clock() - started >= self.limits.request_seconds
                or self.clock() - self.started >= self.limits.study_seconds
            ):
                receipt["reason"] = "elapsed_limit"
            elif receipt["http_status"] != 200:
                receipt["reason"] = "http_status"
            elif not raw:
                receipt["reason"] = "empty_body"
            else:
                receipt["reason"] = "transport_complete"
        compressed = gzip.compress(raw, mtime=0)
        durable(directory / "response.raw.gz", compressed)
        receipt.update(
            {
                "request_completed_at_utc": self.now().isoformat(),
                "elapsed_seconds": self.clock() - started,
                "raw_sha256": sha(raw),
                "gzip_sha256": sha(compressed),
                "gzip_bytes": len(compressed),
                "partial_body": receipt["reason"]
                in ("transport_exception", "body_or_cohort_limit", "elapsed_limit"),
                "status": "CAPTURED"
                if receipt["reason"] == "transport_complete"
                else "UNEVALUABLE",
            }
        )
        durable(directory / "RESULT.json", encode(receipt))
        self.packaging.append(
            {
                "file": str(directory.relative_to(self.root) / "response.raw.gz"),
                "role": label,
                "gzip_bytes": len(compressed),
                "gzip_sha256": sha(compressed),
                "raw_sha256": sha(raw),
                "portable": len(compressed) <= 450 * 1024
                and not label.startswith("filing-"),
                "required_portable": not label.startswith("filing-"),
                "publication_kind": "ROOT_ONLY_COMPLETE_SUBMISSION"
                if label.startswith("filing-")
                else "COMPLETE_JSON_OR_FAILURE_BODY",
            }
        )
        if receipt["status"] != "CAPTURED":
            raise StudyFailure(
                "TRANSPORT_FAILURE", receipt["reason"], {"receipt": receipt}
            )
        return raw, receipt

    def components(
        self, issuer_dir: Path, year_index: int, extraction: dict[str, Any]
    ) -> None:
        durable(
            issuer_dir / f"anchor-{year_index}.json",
            encode(
                {
                    "anchor": extraction["anchor"].model_dump(mode="json")
                    if extraction["anchor"] is not None
                    else None,
                    "audit": extraction["audit"],
                }
            ),
        )
        for name, body in extraction["components"].items():
            packed = gzip.compress(body, mtime=0)
            path = issuer_dir / f"anchor-{year_index}-{name}.gz"
            durable(path, packed)
            self.packaging.append(
                {
                    "file": str(path.relative_to(self.root)),
                    "role": name,
                    "gzip_bytes": len(packed),
                    "gzip_sha256": sha(packed),
                    "raw_sha256": sha(body),
                    "portable": len(packed) <= 450 * 1024,
                    "required_portable": True,
                    "publication_kind": "COMPLETE_FINANCIAL_COMPONENT",
                }
            )


def run_study(
    root: Path,
    manifest: dict[str, Any],
    *,
    transport: httpx.BaseTransport | None = None,
    limits: Limits | None = None,
    clock: Callable[[], float] = time.monotonic,
    now: Callable[[], datetime] = utc_now,
    sleep: Callable[[float], None] = time.sleep,
) -> dict[str, Any]:
    limits = limits if limits is not None else Limits()
    limits.validate()
    if manifest != identity_manifest():
        raise ValueError("frozen identity manifest drift")
    if now().tzinfo is None or now() >= DEADLINE:
        raise ValueError("live start expired or naive")
    pre = None
    pre_raw = None
    review_receipts: dict[str, bytes] = {}
    if transport is None:
        if root != ROOT:
            raise ValueError("production transport requires registered root")
        try:
            pre_raw = PREACQUISITION.read_bytes()
            pre = json.loads(pre_raw)
        except (OSError, ValueError) as exc:
            raise ValueError("pre-acquisition manifest missing or invalid") from exc
        if (
            pre.get("identity") != manifest
            or pre.get("research_review") != "APPROVE"
            or pre.get("data_review") != "APPROVE"
        ):
            raise ValueError("pre-acquisition reviews/identity mismatch")
        receipts = pre.get("receipts")
        if not isinstance(receipts, dict) or not {
            "research_review",
            "data_review",
            "focused_test",
        } <= set(receipts):
            raise ValueError("pre-acquisition review/test receipts required")
        for role, receipt in receipts.items():
            if (
                not isinstance(role, str)
                or re.fullmatch(r"[A-Za-z0-9_-]+", role) is None
                or not isinstance(receipt, dict)
            ):
                raise ValueError("invalid pre-acquisition receipt")
            try:
                path = Path(receipt["path"])
                if not path.is_absolute():
                    raise ValueError("receipt path must be absolute")
                body = path.read_bytes()
            except (KeyError, TypeError, OSError) as exc:
                raise ValueError("missing pre-acquisition receipt") from exc
            if sha(body) != receipt.get("sha256"):
                raise ValueError("pre-acquisition receipt SHA mismatch")
            review_receipts[role] = body
    roster = json.loads(ROSTER.read_bytes())["roster"]
    root.mkdir(exist_ok=False)
    start = {
        "identity": manifest,
        "started_at_utc": now().isoformat(),
        "roster": roster,
        "limits": vars(limits),
        "status": "STARTED",
        "preacquisition": pre,
        "preacquisition_sha256": sha(pre_raw) if pre_raw is not None else None,
    }
    durable(root / "START.json", encode(start))
    durable(root / "protocol.md", PROTOCOL.read_bytes())
    durable(root / "method.py", Path(__file__).read_bytes())
    durable(root / "tests.py", (HERE / "test_coverage422.py").read_bytes())
    durable(root / "roster.json", ROSTER.read_bytes())
    if pre_raw is not None:
        durable(root / "PREACQUISITION.json", pre_raw)
        receipt_dir = root / "preacquisition-receipts"
        receipt_dir.mkdir()
        for index, (role, body) in enumerate(sorted(review_receipts.items())):
            durable(receipt_dir / f"{index:03d}-{role}", body)
    collector = Collector(root, limits, transport, clock, now, sleep)
    issuers: list[dict[str, Any]] = []
    status = "COMPLETE"
    invalid: str | dict[str, str] | None = None
    try:
        for item in roster:
            collector.budget()
            symbol, cik = item["symbol"], item["cik"]
            directory = root / f"issuer-{symbol}"
            directory.mkdir()
            durable(
                directory / "START.json",
                encode(
                    {"symbol": symbol, "cik": cik, "started_at_utc": now().isoformat()}
                ),
            )
            terminal: dict[str, Any] = {
                "symbol": symbol,
                "cik": cik,
                "status": "STARTED",
            }
            try:
                raw, receipt = collector.fetch(
                    f"https://data.sec.gov/submissions/CIK{cik:010d}.json",
                    "submissions",
                )
                rows = select_filings(raw, cik)
                collector.budget()
                durable(
                    directory / "SELECTED.json",
                    encode(
                        {
                            "selected_rows": rows,
                            "submissions_raw_sha256": receipt["raw_sha256"],
                        }
                    ),
                )
                extractions = []
                for index, row in enumerate(rows):
                    accession = row["accessionNumber"]
                    url = f"https://www.sec.gov/Archives/edgar/data/{cik}/{accession.replace('-', '')}/{accession}.txt"
                    body, original_receipt = collector.fetch(url, f"filing-{index}")
                    try:
                        extraction = extract_anchor(
                            raw=body,
                            cik=cik,
                            selected=row,
                            observed_at=datetime.fromisoformat(
                                original_receipt["request_completed_at_utc"]
                            ),
                            url=url,
                        )
                    except StudyFailure as exc:
                        collector.components(
                            directory,
                            index,
                            {
                                "anchor": None,
                                "audit": exc.evidence,
                                "components": exc.components,
                            },
                        )
                        if not exc.components:
                            collector.packaging.append(
                                {
                                    "role": "unextractable_financial_components",
                                    "required_portable": True,
                                    "portable": False,
                                }
                            )
                        raise
                    collector.components(directory, index, extraction)
                    extractions.append(extraction)
                    collector.budget()
                body, company_receipt = collector.fetch(
                    f"https://data.sec.gov/api/xbrl/companyfacts/CIK{cik:010d}.json",
                    "companyfacts",
                )
                observation = SourceObservation(
                    url=company_receipt["url"],
                    sha256=company_receipt["raw_sha256"],
                    observed_at=datetime.fromisoformat(
                        company_receipt["request_completed_at_utc"]
                    ),
                )
                evaluation = assemble(
                    raw=body,
                    observation=observation,
                    extractions=extractions,
                    symbol=symbol,
                    as_of=now(),
                )
                collector.budget()
                terminal.update(evaluation)
            except StudyFailure as exc:
                terminal.update(
                    {
                        "status": exc.category,
                        "reason": str(exc),
                        "evidence": exc.evidence,
                    }
                )
            durable(directory / "RESULT.json", encode(terminal))
            issuers.append(terminal)
    except BudgetStop as exc:
        status = "INCOMPLETE"
        invalid = str(exc)
    except Exception as exc:  # noqa: BLE001 - unexpected faults must become INVALID_METHOD
        status = "UNEVALUABLE"
        invalid = {
            "classification": "INVALID_METHOD",
            "exception_type": type(exc).__name__,
            "message": str(exc),
        }
    result = {
        "status": status,
        "coverage": (
            "PASS" if all(item["status"] == "PASS" for item in issuers) else "FAIL"
        )
        if status == "COMPLETE" and len(issuers) == len(roster)
        else "NOT_MEASURED",
        "issuers": issuers,
        "planned_issuers": len(roster),
        "not_requested": [
            item["symbol"]
            for item in roster
            if not (root / f"issuer-{item['symbol']}" / "START.json").exists()
        ],
        "started_without_terminal": [
            item["symbol"]
            for item in roster
            if (root / f"issuer-{item['symbol']}" / "START.json").exists()
            and not (root / f"issuer-{item['symbol']}" / "RESULT.json").exists()
        ],
        "requests": collector.count,
        "retained_raw_bytes": collector.total,
        "elapsed_seconds": clock() - collector.started,
        "completed_at_utc": now().isoformat(),
        "issue": invalid,
        "packaging": collector.packaging,
        "gates": "NOT_MEASURED",
        "alpha_case_improved": False,
    }
    metadata = []
    for path in sorted(root.rglob("*")):
        if path.is_file() and path.suffix not in (".raw", ".gz"):
            body = path.read_bytes()
            packed = gzip.compress(body, mtime=0)
            metadata.append(
                {
                    "file": str(path.relative_to(root)),
                    "raw_sha256": sha(body),
                    "gzip_bytes": len(packed),
                    "portable": len(packed) <= 450 * 1024,
                }
            )
    result["metadata_packaging"] = metadata
    result["publication_acceptance"] = (
        "PASS" if all(item["portable"] for item in metadata) else "FAIL_METADATA_CAP"
    )
    result["portable_completeness"] = (
        "COMPLETE_DECLARED_COMPONENTS"
        if all(
            item["portable"]
            for item in collector.packaging
            if item.get("required_portable", False)
        )
        and result["publication_acceptance"] == "PASS"
        else "ROOT_ONLY_REQUIRED_EVIDENCE"
    )
    durable(root / "RESULT.json", encode(result))
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--live", action="store_true", required=True)
    parser.parse_args()
    pre = json.loads(PREACQUISITION.read_bytes())
    if pre.get("research_review") != "APPROVE" or pre.get("data_review") != "APPROVE":
        raise ValueError("both frozen harness reviews required")
    expected = pre["identity"]
    if expected != identity_manifest():
        raise ValueError("pre-acquisition code/protocol/dependency drift")
    result = run_study(ROOT, expected)
    print(
        json.dumps(
            {
                "status": result["status"],
                "coverage": result["coverage"],
                "requests": result["requests"],
                "root": str(ROOT),
            }
        )
    )


if __name__ == "__main__":
    main()
