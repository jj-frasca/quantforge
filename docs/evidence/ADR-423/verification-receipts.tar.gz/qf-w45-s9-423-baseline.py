import ast
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

from app.data.fundamentals import FundamentalsHistory, parse_company_facts_history
from app.research.fundamentals.quality import piotroski_f_score, quality_score
from app.research.fundamentals.record import FundamentalRecord, compute_fundamental_record

ROOT = Path('/Users/joefrasca/claude-work/quantforge-codex')
OUT = Path('/tmp/qf-w45-s9-423-baseline.json')
def canonical(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'), allow_nan=False)
def capture():
    histories=[]
    for symbol,cik in [('AAPL','0000320193'),('MSFT','0000789019')]:
        raw=gzip.decompress((ROOT/f'docs/evidence/FINDING-322/companyfacts.CIK{cik}.20261030.json.gz').read_bytes())
        h=parse_company_facts_history(json.loads(raw),symbol)
        histories.append(h)
        for end in (2020,2021,2022,2023):
            histories.append(FundamentalsHistory.model_validate({**h.model_dump(), 'years':[y for y in h.years if y.fiscal_year<=end]}))
    for count in (0,1,2,3):
        for sign in (-1,0,1):
            histories.append(FundamentalsHistory(symbol='TEST',cik=1,entity_name='Fixture',form='10-K',accession_number='old',source_url='old',years=[dict(fiscal_year=2020+i,revenue=100+i,net_income=sign*(10+i),total_assets=100+i*20,operating_cash_flow=15+i,total_equity=70,gross_profit=40,total_current_assets=50,total_current_liabilities=20,long_term_debt=10,shares_diluted=20,retained_earnings=30) for i in range(count)]))
    claims=[]
    for h in histories:
        claim={'history':h.model_dump(mode='json'),'f':piotroski_f_score(h).model_dump(mode='json'),'q':quality_score(h).model_dump(mode='json')}
        for price in (None,10.0):
            try: value=compute_fundamental_record(h,price).model_dump(mode='json')
            except Exception as exc: value={'error':type(exc).__name__,'message':str(exc)}
            claim[str(price)]=value
        claims.append(claim)
    records=json.loads((ROOT/'data/fundamentals_pool.json').read_bytes())
    legacy=[FundamentalRecord.model_validate(r).model_dump(mode='json') for r in records]
    paths=subprocess.check_output(['git','ls-files'],cwd=ROOT,text=True).splitlines()
    hashes={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths if p.startswith(('data/','docs/evidence/','backend/tests/'))}
    return {'claims':claims,'legacy':legacy,'hashes':hashes}

if __name__=='__main__':
    import sys
    result=capture()
    if '--check' in sys.argv:
        assert canonical(result)==canonical(json.loads(OUT.read_text()))
        print('EXACT default claims, legacy records, protected hashes',len(result['claims']),len(result['legacy']),len(result['hashes']))
    else:
        OUT.write_text(canonical(result))
        for name in ('quality','record'):
            p=ROOT/f'backend/app/research/fundamentals/{name}.py'
            Path(f'/tmp/qf-w45-s9-423-original-{name}.py').write_bytes(p.read_bytes())
            Path(f'/tmp/qf-w45-s9-423-original-{name}.ast').write_text(ast.dump(ast.parse(p.read_text()),include_attributes=False))
        print('CAPTURED',len(result['claims']),len(result['legacy']),len(result['hashes']))
