"""FundamentalRecord: the per-company score snapshot the fundamental discovery sweep writes
(ADR-029 Layer 3), plus the pure compute / merge / leaderboard logic around it.

The sweep enumerates the SEC CIK universe, fetches each company's `FundamentalsHistory` (EDGAR,
free), computes a `FundamentalRecord`, and appends it to a sharded output; a consolidation job
`merge_fundamental_records` folds every shard into `data/fundamentals_pool.json`, deduping by CIK
and keeping the higher fiscal-year label (incoming wins ties), bounding the pool to one row per
company. `rank_fundamentals`
is the leaderboard: the genuinely good, reasonably priced companies. All network-free (the network
lives in the sweep script). New records retain supplied history citations (ADR-399); legacy
attribution can be unknown. No established as-of timestamp or per-fact provenance is certified
(FINDING-335); scores flag potential, never guarantee."""

import json
import math
from pathlib import Path

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    ValidationError,
    field_serializer,
    model_validator,
)

from app.data.flow_facts import AnnualFlowFacts
from app.data.fundamentals import FundamentalsHistory
from app.research.fundamentals.quality import quality_score
from app.research.valuation.score import score_valuation

_RANK_FIELDS = {
    "combined": "combined_score",
    "quality": "quality_score",
    "value": "value_score",
}


class FundamentalHistoryCitation(BaseModel):
    """Supplied history metadata only; no fact ownership, source authenticity or PIT certification."""

    model_config = ConfigDict(
        frozen=True, revalidate_instances="always", extra="forbid", strict=True
    )

    symbol: str
    cik: int
    entity_name: str
    form: str
    accession_number: str
    source_url: str
    source: str


class FundamentalRecord(BaseModel):
    """One company's score snapshot labelled by its latest selected fiscal year (ADR-029).
    Supplied history citations may be retained; no as-of time or per-fact provenance is established
    (FINDING-335/ADR-399). `quality_score` is the
    ADR-029 composite; `value_score` is the ADR-022 UndervaluationScore (only when a price was
    available); `combined_score` = quality * value when BOTH exist (good AND cheap), else None.
    Raw legs (`f_score`, `gross_profitability`) and `flags` travel with the row for legibility."""

    model_config = ConfigDict(frozen=True, allow_inf_nan=False)

    symbol: str
    cik: int
    fiscal_year: int  # latest selected row's fiscal label; not an established as-of timestamp
    quality_score: float | None = Field(ge=0.0, le=1.0)
    value_score: float | None = Field(ge=0.0, le=1.0)
    combined_score: float | None = Field(ge=0.0, le=1.0)
    f_score: int = Field(ge=0, le=9)
    gross_profitability: float | None
    flags: tuple[str, ...] = ()
    # ADR-095: the SEC SIC industry classification description, from a separate EDGAR endpoint
    # (submissions, not companyfacts). None for every row swept before ADR-095 and for any company
    # whose submissions record omits it — absent is not a claim about the company's industry.
    sic_description: str | None = None
    # ADR-146: the raw numeric SIC code from the same submissions response, kept as EDGAR returns
    # it (a string, e.g. "3571") rather than parsed to int — every consumer so far wants prefix
    # matching against the SIC major-group/division scheme, not arithmetic.
    sic_code: str | None = None
    flow_fact_history: tuple[AnnualFlowFacts, ...] | None = Field(
        default=None, exclude_if=lambda value: value is None
    )
    history_citation: FundamentalHistoryCitation | None = Field(
        default=None, exclude_if=lambda value: value is None
    )

    @model_validator(mode="after")
    def validate_combined_score(self) -> "FundamentalRecord":
        if self.quality_score is None or self.value_score is None:
            if self.combined_score is not None:
                raise ValueError("combined_score requires both quality_score and value_score")
            return self
        expected = self.quality_score * self.value_score
        if self.combined_score is None or not math.isclose(
            self.combined_score, expected, rel_tol=1e-12, abs_tol=1e-12
        ):
            raise ValueError("combined_score must equal quality_score * value_score")
        return self

    @model_validator(mode="after")
    def validate_history_citation(self) -> "FundamentalRecord":
        if self.history_citation is not None and (
            self.history_citation.symbol != self.symbol or self.history_citation.cik != self.cik
        ):
            raise ValueError("history citation must match record symbol and CIK")
        return self

    @field_serializer("flags")
    def serialize_flags(self, flags: tuple[str, ...]) -> list[str]:
        return list(flags)


def compute_fundamental_record(
    history: FundamentalsHistory,
    price: float | None = None,
    sic_description: str | None = None,
    sic_code: str | None = None,
) -> FundamentalRecord:
    """Compute a FundamentalRecord from a company's history (and optionally its latest price and SIC
    classification). Quality is always computed from EDGAR alone; value is added only when `price` is
    supplied, and `combined` only when both quality and value are present. After scoring, retain the
    supplied history envelope, including for empty histories (ADR-399), without certifying facts or
    an as-of time. Empty history yields an
    all-None record that still records the company's identity (and flags why nothing was computable).
    `sic_description`/`sic_code` are passed through as-is (ADR-095/146) — this function stays
    network-free."""
    q = quality_score(history)
    flags = list(q.flags)

    value_score: float | None = None
    if price is not None and history.years:
        valuation = score_valuation(history, price)
        value_score = valuation.score
        flags.extend(valuation.flags)

    combined: float | None = None
    if q.score is not None and value_score is not None:
        combined = q.score * value_score

    fiscal_year = history.years[-1].fiscal_year if history.years else 0
    return FundamentalRecord(
        symbol=history.symbol,
        cik=history.cik,
        fiscal_year=fiscal_year,
        quality_score=q.score,
        value_score=value_score,
        combined_score=combined,
        f_score=q.f_score.score,
        gross_profitability=q.gross_profitability,
        flags=tuple(flags),
        sic_description=sic_description,
        sic_code=sic_code,
        history_citation=FundamentalHistoryCitation(
            symbol=history.symbol,
            cik=history.cik,
            entity_name=history.entity_name,
            form=history.form,
            accession_number=history.accession_number,
            source_url=history.source_url,
            source=history.source,
        ),
        flow_fact_history=(
            tuple(
                AnnualFlowFacts(fiscal_year=y.fiscal_year, facts=y.flow_facts)
                for y in history.years
            )
            if any(y.flow_facts is not None for y in history.years)
            else None
        ),
    )


def merge_fundamental_records(
    existing: list[FundamentalRecord], incoming: list[FundamentalRecord]
) -> list[FundamentalRecord]:
    """Fold `incoming` into `existing`, deduping by CIK: keep the higher fiscal-year label,
    and on a tie let `incoming` win (so a re-run of a shard refreshes in place — idempotent).
    Without filing/availability metadata this does not establish the newer filing (FINDING-335).
    The complete winner carries its own citation or unknown attribution, without borrowing metadata.
    Deduping by CIK bounds the pool to one row per company (ADR-029 / ADR-026 bounding)."""
    validated_existing = [
        FundamentalRecord.model_validate(record.model_dump(round_trip=True)) for record in existing
    ]
    validated_incoming = [
        FundamentalRecord.model_validate(record.model_dump(round_trip=True)) for record in incoming
    ]
    by_cik: dict[int, FundamentalRecord] = {r.cik: r for r in validated_existing}
    for rec in validated_incoming:
        current = by_cik.get(rec.cik)
        if current is None or rec.fiscal_year >= current.fiscal_year:
            by_cik[rec.cik] = rec
    return list(by_cik.values())


def load_fundamentals_pool(path: Path) -> list[FundamentalRecord]:
    """Read the consolidated pool. Absent file -> no records: the pool is written only by the cloud
    sweep (ADR-030), so a fresh clone or a pre-first-sweep repo must degrade to "no scores" rather
    than crash whatever is reading it."""
    if not path.exists():
        return []
    return [FundamentalRecord.model_validate(row) for row in json.loads(path.read_text())]


def load_fundamentals_shard(path: Path) -> list[FundamentalRecord] | None:
    """Read one sweep shard, tolerating a corrupt file. `None` (not `[]`, to distinguish "corrupt"
    from "genuinely empty shard") on truncated/invalid JSON or a record that fails validation —
    a shard writer killed mid-write (FINDING-057/ADR-129) must not cost every OTHER shard's work
    in the same consolidation run, mirroring the sweep's own "a bad name never crashes the shard"
    resilience (fundamental_sweep.py)."""
    try:
        return load_fundamentals_pool(path)
    except (json.JSONDecodeError, ValidationError):
        return None


def ambiguous_fundamental_symbols(records: list[FundamentalRecord]) -> set[str]:
    """Find case-insensitive symbol labels shared by distinct company identities."""
    owners: dict[str, set[int]] = {}
    for record in records:
        owners.setdefault(record.symbol.upper(), set()).add(record.cik)
    return {symbol for symbol, ciks in owners.items() if len(ciks) > 1}


def score_maps(
    records: list[FundamentalRecord],
) -> tuple[dict[str, float], dict[str, float]]:
    """Project the fundamentals pool into (quality_scores, value_scores) symbol->score maps for the
    cross-sectional hunt (ADR-029 4a). A symbol appears in a map only when that leg is not None, so
    an unscored name is simply absent — the ranker excludes it that day.
    Cross-company symbol ambiguity refuses before leg filtering (ADR-371);
    neither input order nor missingness can resolve current symbol ownership."""
    ambiguous = ambiguous_fundamental_symbols(records)
    if ambiguous:
        raise ValueError(f"ambiguous fundamental symbol ownership: {', '.join(sorted(ambiguous))}")
    quality = {r.symbol: r.quality_score for r in records if r.quality_score is not None}
    value = {r.symbol: r.value_score for r in records if r.value_score is not None}
    return quality, value


def rank_fundamentals(
    records: list[FundamentalRecord], *, by: str = "combined", top: int | None = None
) -> list[FundamentalRecord]:
    """Leaderboard: rank `records` descending by the `by` score ("combined" | "quality" | "value"),
    dropping rows whose chosen score is None. `top` truncates to the best N (None = all)."""
    field = _RANK_FIELDS[by]
    scored = [r for r in records if getattr(r, field) is not None]
    scored.sort(key=lambda r: getattr(r, field), reverse=True)
    return scored[:top] if top is not None else scored
